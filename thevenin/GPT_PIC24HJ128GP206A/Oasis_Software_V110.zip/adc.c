#include "p24fj128ga006.h"
#include "math.h"
#include "tables.h"
#include "defines.h"
#include "adc.h"

#define VBatVHigh 680	//> 68V on DC bus will turn off PWM.
#define VBatVLow 200	//< 20V on DC bus will turn off PWM.

//-----------------------------------------------------------------
//ADC Initialisation
//-----------------------------------------------------------------
void ADC_Init(void)
{
	AD1CON2 = 0;				//1.B Clear the A/D Control Register 2; Sets Vr+ to AVdd and Vr- to AVss
								// Do not scan inputs
								// Interrupts at the completion of conversion for each sample/convert sequence
								// Buffer configured as one 16-word buffer (AD1BUFn<15:0>)
								// Always uses MUX A input multiplexer settings
	
	AD1CSSLbits.CSSL0 = 1;		//Scan ADC0	- VBat
	AD1CSSLbits.CSSL1 = 1;		//Scan ADC1 - Vinv
	AD1CSSLbits.CSSL2 = 1;		//Scan ADC2 - Iinv
	AD1CSSLbits.CSSL3 = 1;		//Scan ADC3 - Heatsink Temp
	AD1CSSLbits.CSSL4 = 1;		//Scan ADC4 - Vsrc
	AD1CSSLbits.CSSL5 = 1;		//Scan ADC5 - Isrc
	
	AD1CON3bits.ADCS = 0x02;	//select the analog conversion clock prescaler
	AD1CON3bits.SAMC = 0x04;	//Auto conversion sample time = 2 x TAD (Time to allow sample/hold cap to charge)
	AD1CON3bits.ADRC = 0;		//Clock derived from system clock
	//AD1CON1bits.ASAM = 0;		//Sampling begins when SAMP bit is set
	AD1CON1bits.ASAM = 1;		//Auto sampling
	AD1CON1bits.SSRC = 7;		//Internal counter ends sampling starts conversion
	AD1CON1bits.FORM = 0;		//Data format = simple 10-bit integer
	AD1CON1bits.ADSIDL = 1;		//Stop in Idle Mode
	AD1CON2 = 0x0430;			//Set AD1IF after every 12 samples, enable scanning
	AD1CON1bits.ADON = 1;		//ADC Module is Enabled	
}

//-----------------------------------------------------------------
//Do all the necessary measurements
//-----------------------------------------------------------------
void ADC_measure_all(void)
{
	long int RMS_Temp;
	long int Calc_temp;
	long int Perr;
	long int Ierr;
	unsigned long int FFtemp;
	int Pval;
	int Ival;
	unsigned long RMS_Calc;
	
	RMS_Count++;

	//Measure Heatsink temperature
	Hs_temp_temp = ADC1BUF3 + ADC1BUF9;
	Hs_temp_temp *= Hs_temp_cal;
	Hs_temp_temp >>= 10;		//Do calibration
	Heatsink_temp *= 7;			//filter measurements. (Not the best way, but since it's only temperature, it's ok)
	Heatsink_temp += (unsigned int)(Hs_temp_temp);
	Heatsink_temp >>= 3;

	//Measure Battery voltage
	Vbat_temp = ADC1BUF0 + ADC1BUF6;			//Get instantaneous Vbat measurement from ADC
	Vbat_temp *= (unsigned long)(Vbat_cal);		//Apply calibration scaling
	Vbat_temp >>= 11;
	VBat_sum += Vbat_temp;						//Want to get an average of the battery voltage measurement over one output cycle
												//because there will be ripple on the battery voltage.
	
	if(Vbat_temp > VBatVHigh)					//Fast Over-voltage protection
	{
		BatVHighCnt++;
		if(BatVHighCnt > 1) BatVVHigh = 1;
	}
	else
	{
		BatVHighCnt = 0;
	}
	
	if(Vbat_temp < VBatVLow)					//Fast Under-voltage protection
	{
		BatVLowCnt++;
		if(BatVLowCnt > 1) BatVVLow = 1;
	}
	else
	{
		BatVLowCnt = 0;
	}

	//Measure Inverter output voltage	
	Vac_temp = (ADC1BUF1 + ADC1BUF7) * 2;		//Get instantaneous value of Vac from ADC Buffer
	Vac_AVG_temp += Vac_temp;
	
	//Measure Inverter output (load) current	
	Iac_temp = (ADC1BUF2 + ADC1BUF8) * 2;		//Get instantaneous value of Iac from ADC Buffer
	Iac_AVG_temp += Iac_temp;
	
	//Measure Source voltage	
	Vsrc_temp = (ADC1BUF4 + ADC1BUFA) * 2;		//Get instantaneous value of Vsrc from ADC Buffer
	Vsrc_AVG_temp += Vsrc_temp;
	
	//Measure Source current	
	Isrc_temp = (ADC1BUF5 + ADC1BUFB) * 2;		//Get instantaneous value of Isrc from ADC Buffer
	Isrc_AVG_temp += Isrc_temp;
	
	IFS0bits.AD1IF = 0;							// clear ADC interrupt flag
	
	Vac_temp -= (int)(Vac_AVG);					//Remove DC Offset now for RMS calculation
	Iac_temp -= (int)(Iac_AVG);
	
	Vsrc_temp -= (int)(Vsrc_AVG);				//Remove DC Offset now for RMS calculation
	Isrc_temp -= (int)(Isrc_AVG);
	
	Calc_temp = (long int)(Vac_temp);			//Scale Instantaneous Inverter Voltage measurement
	Calc_temp *= (long int)(Vac_cal);			//using calibration value
	Calc_temp /= 1024;							//Cant >> signed values
	Vac_temp = Calc_temp;
	
	Calc_temp = (long int)(Iac_temp);			//Scale Instantaneous Inverter Current measurement
	Calc_temp *= (long int)(Iac_cal);			//using calibration value
	Calc_temp /= 1024;
	Iac_temp = Calc_temp;
	
	Calc_temp = (long int)(Vsrc_temp);			//Scale Instantaneous Source Voltage measurement
	Calc_temp *= (long int)(Vsrc_cal);			//using calibration value
	Calc_temp /= 1024;
	Vsrc_temp = Calc_temp;
	
	Calc_temp = (long int)(Isrc_temp);			//Scale Instantaneous Source Current measurement
	Calc_temp *= (long int)(Isrc_cal);			//using calibration value
	Calc_temp /= 1024;
	Isrc_temp = Calc_temp;
	
	Calc_temp = (long int)(Vac_temp);			//Calculate Instantaneous Inverter power
	Calc_temp *= (long int)(Iac_temp);
	Calc_temp /= 25;							//Vac is 5 times too big, Iac is 50 times too big (should be /= 250)
	Pwr_RMS_sum += (long int)(Calc_temp);
	
	//The Master TX pin will output a square wave indicating the inverter's phase
	if((Vinv_old < 0) && (Vac_temp >= 0))
	{
		Inv_Zero_Cross = 0;
	}
	else
	{
		Inv_Zero_Cross++;
	}
	
	//Used to Synchronise with the Source for charging purposes
	if((Vsrc_old < 0) && (Vsrc_temp >= 0))
	{
		Zero_cross = 1;	//Check for source voltage zero-crossing;
		if((Vinv_old < 0) && (Vac_temp < 0)) VInv_Src_temp = 1;		//Inverter lagging
		if((Vinv_old > 0) && (Vac_temp > 0)) VInv_Src_temp = -1;	//Inverter leading
		if((Vinv_old < 0) && (Vac_temp >= 0))						//Synchronised
		{
			VInv_Src_temp = 0;
			Inv_sync = 1;	
		}
		else Inv_sync = 0;
	}
	else
	{
		Zero_cross = 0;
		Inv_sync = 0;
	}
	Vsrc_old = Vsrc_temp;
	Vinv_old = Vac_temp;
	
	//Calculate the squares of the measurements for RMS calculations
	RMS_Temp = (long int)(Vac_temp);
	RMS_Temp *= 2;
	RMS_Temp *= RMS_Temp;
	RMS_Calc = (unsigned long)(RMS_Temp);
	Vac_RMS_sum += RMS_Calc;
	
	RMS_Temp = (long int)(Iac_temp);
	RMS_Temp *= 2;
	RMS_Temp *= RMS_Temp;
	RMS_Calc = (unsigned long)(RMS_Temp);
	Iac_RMS_sum += RMS_Calc;
	
	RMS_Temp = (long int)(Vsrc_temp);
	RMS_Temp *= 2;
	RMS_Temp *= RMS_Temp;
	RMS_Calc = (unsigned long)(RMS_Temp);
	Vsrc_RMS_sum += RMS_Calc;
	
	RMS_Temp = (long int)(Isrc_temp);
	RMS_Temp *= 2;
	RMS_Temp *= RMS_Temp;
	RMS_Calc = (unsigned long)(RMS_Temp);
	Isrc_RMS_sum += RMS_Calc;
	
	if(RMS_Count == 0x80)				//One output cycle is 128 samples (or 0x80)
	{
		RMS_Count = 0;
		
		Vac_AVG_temp >>= 7;				//Get Average of AC Voltage measurements
		Vac_AVG = Vac_AVG_temp;			//Used for removing offset
		Vac_AVG_temp = 0;		
				
		Iac_AVG_temp >>= 7;				//Get Average of AC Current measurements
		Iac_AVG = Iac_AVG_temp;			//Used for removing offset
		Iac_AVG_temp = 0;
		
		Vsrc_AVG_temp >>= 7;			//Get Average of Src Voltage measurements
		Vsrc_AVG = Vsrc_AVG_temp;		//Used for removing offset
		Vsrc_AVG_temp = 0;		
				
		Isrc_AVG_temp >>= 7;			//Get Average of AC Current measurements
		Isrc_AVG = Isrc_AVG_temp;		//Used for removing offset
		Isrc_AVG_temp = 0;
				
		Vac_RMS_sum >>= 7;				//Take the mean of the squares
		RMS_Calc = sqrt2(Vac_RMS_sum);	//Take square root, to get true RMS value
		Vac_RMS = RMS_Calc;
		Vac_RMS_sum = 0;
		
		Iac_RMS_sum >>= 7;				//Take the mean of the squares
		RMS_Calc = sqrt2(Iac_RMS_sum);	//Take square root, to get true RMS value
		Iac_RMS = RMS_Calc;
 		Iac_RMS_sum = 0;

		Vsrc_RMS_sum >>= 7;				//Take the mean of the squares
		RMS_Calc = sqrt2(Vsrc_RMS_sum);	//Take square root, to get true RMS value
		Vsrc_RMS = RMS_Calc;
		Vsrc_RMS_sum = 0;
		
		Isrc_RMS_sum >>= 7;				//Take the mean of the squares
		RMS_Calc = sqrt2(Isrc_RMS_sum);	//Take square root, to get true RMS value
		Isrc_RMS = RMS_Calc;
 		Isrc_RMS_sum = 0;
		
		Pwr_RMS_sum /= 1280;			//Get the average power(/128) and remove decimal (/10)
		PoutW = (int)(Pwr_RMS_sum);
		Pwr_RMS_sum = 0;
		
		Ichg = Isrc_RMS - Iac_RMS;		//Calculate charging current (Source current - Load current)
		
		VBat_sum >>= 7;		
		VBat *= 7;
		VBat += (unsigned int)(VBat_sum);
		VBat /= 8;						//Data table is now all signed vals, must divide, cant >>
		
		Inverter_Load = Iac_RMS;	//Two decimals, so 
		Inverter_Load *= 70;		//Used 70 insted of 100 to get a better range that the master can send
		Inverter_Load /= (Imax);	//Inverter_Load now holds a percentage of full load (based on current)

		//---------------------------------------------------------------------------------------------
		//Feed-forward control added 08/03/11
		//Calculates an approximate modulation index based on Battery voltage and transformer constant
		//Transformer constant is about 5.8 for a 48V system - Calculated by:
		//(230/28)/1.414 = 5.8 - Dividing by 1.414 here removes the need to divide Vbat by 1.414
		//To calculate Modulation index:
		//Vout = 5.8*Vbat*Modulation
		//So - Modulation = Vout/(5.8*Vbat)
		//Since we cant use 5.8, use 58 and divide by 10 later
		//Vbat and Vout are also x10 because of 1 decimal resolution.
		//So - Modulation = (Vout*10)/(58*Vbat)
		//Since Modulation in the above formula is a percentage, we must multipy by 100% modulation index
		//PWM_Period = 100% modulation index so
		//amplitude = (Vout*PWM_Period*10)/(58*Vbat)
		//---------------------------------------------------------------------------------------------
		
		FFtemp = Vout;
		FFtemp *= PWM_Period;
		FFtemp *= 10;
		//Using VBat_sum as a u32 temp variable here (ok, because Average battery voltage already taken)
		VBat_sum = VBat;
		VBat_sum *= Transformer_const;
		FFtemp /= VBat_sum;
		amplitude_target = FFtemp;
		Ramp_max = FFtemp;			//Use this as the maximum amplitude during ramp-up mode
		
		//Must clear VBat_sum so that next Battery voltage average works ok.
		VBat_sum = 0;
		//End of Feed-forward control
	
		if(INV_MODE == INV_MODE_RUNNING)	//Only use feedback control when in run mode to prevent glitches
		{									//when switching from ramp-up to run mode
			if(Stop_feedback > 0)			//Stop_feedback is used to disable feedback control temporarily
			{								//Useful when switching between different modes of operation,
				Stop_feedback--;			//because the integral error could otherwise become quite large
			}								//and cause problems with the output voltage.
			else
			{
				Vac_Err = Vout - Vac_RMS;					//Simple PI control
				Error_sum += (long int)(Vac_Err);
				if(Error_sum > 4096) Error_sum = 4096;
				if(Error_sum < -4096) Error_sum = -4096;
					
				Perr = (long int)(Vac_Err);					//Proportional error
				Perr *= (long int)(Kp);
				Perr /= 1024;
				Pval = (int)(Perr);
				
				Ierr = (long int)(Error_sum);				//Integral error
				Ierr *= (long int)(Ki);
				Ierr /= 1024;
				Ival = (int)(Ierr);
				
				amplitude_target += Pval;
				if((amplitude_target + Ival) < amp_max) amplitude_target += Ival;
				else
				{
					Ival = amp_max - amplitude_target;
					Ierr = Ival;
					Ierr *= (long int)(1024);
					Ierr /= (long int)(Ki);
					Error_sum = Ierr;
					amplitude_target = amp_max;
				}
			}
		}
		else
		{
			if((INV_MODE != INV_MODE_REQ_CHARGE) && (INV_MODE != INV_MODE_CHARGING) && (INV_MODE != INV_MODE_STOP_CHG) && (INV_MODE != INV_MODE_SRC_REC))	//If we start charging, we want to remember the old values, to allow faster recovery when we stop charging.
			{
				Ierr = 0;	//To avoid glitches when changing from ramp-up to run mode,
				Ival = 0;	//the error only gets calculated when in run mode
				Perr = 0;
				Pval = 0;
				Error_sum = 0;
			}
		}
	}
}
