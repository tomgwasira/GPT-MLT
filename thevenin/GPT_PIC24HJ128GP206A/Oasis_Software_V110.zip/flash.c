
#include "p24fj128ga006.h"
#include "p24Fxxxx.h"
#include "UART.h"
#include "DEE Emulation 16-bit.h"
#include "tables.h"
#include "flash.h"

//------------------------------------------------------------
//This function writes all the calibration values to flash memory
//------------------------------------------------------------
void Write_cal_flash(void)
{
	unsigned char i;
	
	for(i = 0; i < max_cal_table; i++)
	{
		if(DataEEWrite(calibrations[i],i) != 0) UART_printf("Flash write failed!");
	}
}

//------------------------------------------------------------
//This function reads all the calibration values from flash memory
//If the memory was blank, default values are used, and written
//to the flash memory
//------------------------------------------------------------
void Read_cal_flash(void)
{
	unsigned char i;
	
	for(i = 0; i < max_cal_table; i++)
	{
		calibrations[i] = DataEERead(i);
	}
	if((calibrations[0] < 100) || (calibrations[0] > 2048))	//Calibration values not initialised yet
	{
		Vbat_cal = 799;
		Vac_cal = 1065;
		Iac_cal = 1410;
		Vsrc_cal = 1302;
		Isrc_cal = 1450;
		Vout = 2300;
		VBat_high_24 = 318;
		VBat_low_24 = 216;
		VBat_recon_24 = 240;
		VBat_high_36 = 477;
		VBat_low_36 = 324;
		VBat_recon_36 = 360;
		VBat_high_48 = 636;
		VBat_low_48 = 432;
		VBat_recon_48 = 480;
		Pmax = 4000;
		Psense_run = 5;
		Psense_ramp = 4;
		Sense_time = 3000;
		Sense_off_time = 10000;
		Ramp_max = 800;
		Hs_temp_cal = 1650;
		Hs_temp_hi = 750;
		Hs_temp_rec = 650;
		Sw_freq = 10000;
		Output_freq = 500;
		Kp = 400;
		Ki = 100;
		Ichg_HI = 1000;
		Ichg_LO = 500;
		SC_timeout = 10;

		Write_cal_flash();	//Write default values to flash
	}
	
	//Calculate Max. Current from Max. Power assuming 230V output (Lower output voltage will overload at lower power, but same current)
	//I ac measurement has 2 decimals, so e.g. 17A would be 1700
	Imax = Pmax * 3;		//Would like to use *10 and /23, but Imax is a signed int, so 4000*10 would be too large
	Imax /= 7;				//so *3 and /7 is very close, but slighly lower than what we want
	Imax += 100;			//Add 1.0A just to correct the calculation error and increase overload a little
	
	//Apply limits to certain important values
	//(More to protect from corrupt flash than operator error, as changes should only be made in the factory)
	if((Output_freq > 620) || (Output_freq < 450)) Output_freq = 500;
	if(Vout > 2500) Vout = 2300;
	if((Sw_freq > 16000) || (Sw_freq < 7000)) Sw_freq = 10000;
	if(Kp > 2048) Kp = 400;
	if(Ki > 1024) Ki = 100;
	
	
}
