
#include "p24fj128ga006.h"

void UART_Init(void);
void UART_char_Tx(unsigned char ch);
void UART_printf(const char *instring);
void UART_num_Tx(unsigned long bigNumber);
void UART_Int_TX(unsigned int num,unsigned char len);
void UART_Frac_TX(unsigned int num,unsigned char units,unsigned char decimal);
void UART_S16_Tx(int num);
void UART_SFrac_TX(int num, unsigned char decimal);
