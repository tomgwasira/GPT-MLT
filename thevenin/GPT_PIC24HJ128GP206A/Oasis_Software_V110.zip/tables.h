//Tables.h automatically created in Excel		
		
#define	max_cal_table	31
#define	max_Data_table	26
		
typedef struct cals		
{		
	const char * Tag;	
	const char * Units;	
	const unsigned char Scale;	
} CalType;

typedef struct tags
{		
	const char * Tag;	
} TagType;		
		
extern unsigned int calibrations[max_cal_table];		
extern const CalType Cal_names[max_cal_table];		
extern const CalType Data_names[max_Data_table];		
extern const TagType System_modes[3];		
extern const TagType Inverter_modes[4];		
		
		
#define	Vbat_cal	calibrations[0]
#define	Vac_cal	calibrations[1]
#define	Iac_cal	calibrations[2]
#define	Vsrc_cal	calibrations[3]
#define	Isrc_cal	calibrations[4]
#define	Hs_temp_cal	calibrations[5]
#define	Ramp_max	calibrations[6]
#define	Sw_freq	calibrations[7]
#define	Output_freq	calibrations[8]
#define	VBat_high_24	calibrations[9]
#define	VBat_low_24	calibrations[10]
#define	VBat_recon_24	calibrations[11]
#define	VBat_high_36	calibrations[12]
#define	VBat_low_36	calibrations[13]
#define	VBat_recon_36	calibrations[14]
#define	VBat_high_48	calibrations[15]
#define	VBat_low_48	calibrations[16]
#define	VBat_recon_48	calibrations[17]
#define	Vout	calibrations[18]
#define	Pmax	calibrations[19]
#define	Psense_run	calibrations[20]
#define	Psense_ramp	calibrations[21]
#define	Sense_time	calibrations[22]
#define	Sense_off_time	calibrations[23]
#define	Hs_temp_hi	calibrations[24]
#define	Hs_temp_rec	calibrations[25]
#define	Kp	calibrations[26]
#define	Ki	calibrations[27]
#define Ichg_HI calibrations[28]
#define Ichg_LO calibrations[29]
#define SC_timeout calibrations[30]
		
#define	amplitude	Data_table[0]
#define	VBat	Data_table[1]
#define	Vac_RMS	Data_table[2]
#define	Iac_RMS	Data_table[3]
#define	Vac_AVG	Data_table[4]
#define	Iac_AVG	Data_table[5]
#define	Pout	Data_table[6]
#define	Vsrc_RMS	Data_table[7]
#define	Isrc_RMS	Data_table[8]
#define	Vsrc_AVG	Data_table[9]
#define	Isrc_AVG	Data_table[10]
#define	Heatsink_temp	Data_table[11]
#define	PoutW	Data_table[12]
#define	PsrcW	Data_table[13]
#define	Imax	Data_table[14]
#define Ichg	Data_table[15]
#define Ichg_max	Data_table[16]
#define Vchg_max	Data_table[17]
#define Pout_avg	Data_table[18]
#define Red_LED		Data_table[19]
#define Yellow_LED		Data_table[20]
#define Green_LED		Data_table[21]
#define Inv_Load_T		Data_table[22]
#define Mstr_Load_T		Data_table[23]
#define Inverter_PF		Data_table[24]
#define Phase_offset	Data_table[25]
