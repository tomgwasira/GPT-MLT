
extern unsigned int PWM_qtr_period;
extern unsigned int PWM_Period;
extern unsigned int PWM_charge_Max;
extern unsigned long PWM_offset;
extern unsigned long PWM_limit;
extern const unsigned char dead_time;
extern unsigned int amp_max;

void PWM_Init(void);
void Sw_freq_calc(void);
void PWM_off(void);
void PWM_on(void);
void PWM_on_charge(void);
