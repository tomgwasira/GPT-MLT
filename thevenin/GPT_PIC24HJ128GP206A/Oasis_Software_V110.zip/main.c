//Created by: Stanley Adams 2010
//Creates Unipolar PWM signals on OC1, OC2, OC3 and OC4
//OC1 and OC3 are the HIGH side PWM signals
//OC2 and OC4 are the LOW side PWM signals
//Inverter LED on RG9
//Overload LED on RG8
//Batt Low LED on RG7
//Auto switch on RB15
//Manual switch on RB14 (Three position rocker switch on-off-on connects to Auto and Manual inputs)

//LED BIT flags:
//Green LED: 0 - Charging; 1 - Src Flt; 2 - Sys off;  3 - Inv On
//Yellow LED:0 - Src Flt;  1 - Sys off; 2 - Rev pwr;  3 - Bat Low; 4 - Over Tmp; 5 - On Grid
//Red LED:   0 - Src Flt;  1 - Sys off; 2 - Overload; 3 - Rev Pwr; 4 - Batt Hi;  5 - Short cct.

//Revision notes
//V1.00 - First prototype testing version
//V1.01 - Bug fix release
//V1.02 - Bug fix release
//V1.03 - Added charging capability
//V1.04 - Fixed bug: Inverter would not start charging if in battery low when source is connected.
//		- Created an error if a voltage is measured on the output when the inverter is off.
//V1.05 - Added very fast DC Over-voltage protection.
//V1.07 - Fixed bug with feed-forward control. If DC voltage was fairly high, AC output dropped to 152V
//V1.08 - Added output frequency adjustment with battery voltage. Increases frequency linearly by up to 3Hz between Bulk voltage and battery high
//V1.09 - Added support for 24V systems. For 24V systems: Leave J12 open, solder 11k resistor between pins 1-2 of J11.
//V1.10 - WIP. Trying to add support for parallel inverters and / or 3 phase operation

//End of Revision Notes

#include "p24fj128ga006.h"
#include "Sine8192.h"
#include "UART.h"
#include "lcd.h"
#include "pwm.h"
#include "timers.h"
#include "adc.h"
#include "debug.h"
#include "tables.h"
#include "DEE Emulation 16-bit.h"
#include "flash.h"
#include "defines.h"

//Battery charging voltages are hard coded
#define Float24 282		//2.35VPC on 24V machine is 28.2V
#define Bulk24 294		//2.45VPC on 24V machine is 29.4V
#define Float36 423		//2.35VPC on 36V machine is 42.3V
#define Bulk36 441		//2.45VPC on 36V machine is 44.1V
#define Float48 564		//2.35VPC on 48V machine is 56.4V
#define Bulk48 588		//2.45VPC on 48V machine is 58.8V

#define Vsrc_VVLow 1200	//Below 120V, Source will disconnect quickly

//-----------------------------------------------------------------
//Variable definitions
//-----------------------------------------------------------------

extern const CalType Cal_names[max_cal_table];

const unsigned char dead_time = 8;   //Dead time is this value * 125nS
const u16 Button_delay = 50;		 //Button debounce in ms
//const u8 SC_timeout = 10;			 //Time between re-tries on Short-cct in Seconds
const u16 UV_timeout = 300;			 //Batt low integration time (Seconds)
const u16 Error_thresh = 18;		 //No. of Errors per cycle, above which a short circuit error will be recorded

const u8 Transformer_const_48 = 59;	 //Used for feed-forward control
const u8 Transformer_const_36 = 77;	 //Used for feed-forward control
const u8 Transformer_const_24 = 118; //Used for feed-forward control

u16 calibrations[max_cal_table];
s16 Data_table[max_Data_table];

s32 PWM_Temp1, PWM_Temp2;
s32 Pwr_RMS_sum;
s32 Pwr_src_sum;
s32 Error_sum;

u32 PWM_Temp3, PWM_Temp4;
u32 Temp3, Temp4;
u32 Temp5, Temp6;
u32 VBat_sum;
u32 Vac_RMS_sum;
u32 Iac_RMS_sum;
u32 Vsrc_RMS_sum;
u32 Isrc_RMS_sum;
u32 Vac_AVG_temp;
u32 Iac_AVG_temp;
u32 Vsrc_AVG_temp;
u32 Isrc_AVG_temp;
u32 Hs_temp_temp;
u32 Vbat_temp;
u32 Power_VA;
u32 PWM_offset;
u32 PWM_limit;
u32 Pout_sum;

s16 Vac_temp;
s16 Iac_temp;
s16 Vac_Err;
s16 Iac_rms_error;
s16 Iac_err_dat;
s16 Vsrc_temp;
s16 Isrc_temp;
s16 Vsrc_old;
s16 Vinv_old;
s16 VInv_Src_temp;
s16 Sin_ref;
s16 Phase_Inc;
s16 Phase_Mult;
s16 Vinc;

u16 Sin_pos, Sin_val, Sin_180;
u16 Sin_temp;
u16 Timer_1ms;
u16 Timer_PWM_error;
u16 Timer_DC;
u16 RMS_Count;
u16 AVG_Count;
u16 Bat_low_count;
u16 Overload_count;
u16 Short_cct_count;
u16 Auto_Sw_count;
u16 Man_Sw_count;
u16 Reset_But_count;
u16 Sense_count;
u16 Error_count;
u16 Debug_val;
u16 PWM_Period;
u16 PWM_qtr_period;
u16 amp_max;
u16 Pout_abs;
u16 amplitude_target;
u16 VBat_high;
u16 VBat_low;
u16 VBat_recon;
u16 VBat_freq_min;
u16 VBat_freq_temp;
u16 VBat_freq_temp1;
u16 VBat_freq_temp2;
u16 PWM_charge;
u16 PWM_charge_Max;
u16 Charge_timer_sec;
u16 Parallel_timer_ms;
u16 Parallel_timer_sec;
u16 Source_reconnect_timer;
u16 Sag_count;
u16 Flash_count;
u16 temp_del;
u16 LED_timer;
u16 Ramp_count;
u16 PR3_calc;
u16 PR3_50Hz;
u16 PR3_53Hz;
u16 Sync_offset;
u16 Inv_sync;
u16 del_cnt;
u32 Master_Sync_offset;
u16 Master_Load;
u32 Inverter_Load;
u16 Master_Load_Sum;
u16 Inverter_Load_Sum;
u16 Highest_Load;
u16 Highest_Load_Old;
u16 Total_Load;
u16 Inverter_PF_Old;
u16 Inverter_PF_Sum;
u16 Master_period;

u8 Reset_pressed;
u8 Reset_state;
u8 Dbg_Start;
u8 Dbg_Len;
u8 Debug_Buf[32];
u8 Debug_cmd;
u8 cycle_cnt;
u8 Bat_UV;
u8 Bat_OV;
u8 Inv_OL;
u8 Inv_SC;
u8 Inv_OT;
u8 Rev_PWR;
u8 INV_MODE;
u8 SYS_MODE;
u8 pwm_error;
u8 Inv_SC_cnt;
u8 Inv_SC_timeout;
u8 Inv_SC_reset;
u8 Inv_OL_cnt;
u8 Inv_OL_timeout;
u8 Inv_OL_reset;
u8 Fan_ena;
u8 Src_spec_cnt;
u8 Source_in_spec;
u8 Chg_inc_cnt;
u8 Chg_dec_cnt;
u8 Chg_volt_reached;
u8 Source_chg_dropout;
u8 Source_low_ridethrough;
u8 Source_vvlow;
u8 Source_is_in_spec;
u8 Inv_restart_timer;
u8 LEDs;
u8 Transformer_const;
u8 Bat_low_beep;
u8 Beep_count;
u8 Stop_feedback;
u8 Beeper;
u8 PWMoffCnt;
u8 BatVHighCnt;
u8 BatVVHigh;
u8 BatVLowCnt;
u8 BatVVLow;
u8 Zero_cross;
u8 Src_rec;
u8 Inv_in_sync;
u8 Src_period;
u8 Freq_sync;
u8 Vsel_res;
u8 Inv_Pos;
u8 Master_Phase;
u8 Master_Phase_Old;
u8 Master_Sync;
u8 Master_Freq_Sync;
u8 Inv_Zero_Cross;
u8 Slave_Cyc;
u8 PF_Cyc;

//-----------------------------------------------------------------
//I/O Initialisation
//Sets the directions of all used I/O pins
//All outputs are also initialised to the correct startup state
//-----------------------------------------------------------------
void IO_Init(void)
{
	//Initialise PWM pins low on startup
	TRISDbits.TRISD0 = OUTPUT;
	TRISDbits.TRISD1 = OUTPUT;
	TRISDbits.TRISD2 = OUTPUT;
	TRISDbits.TRISD3 = OUTPUT;
	LATDbits.LATD0 = 0;
	LATDbits.LATD1 = 0;
	LATDbits.LATD2 = 0;
	LATDbits.LATD3 = 0;
	
	Inv_LED_tris = OUTPUT;
	OL_LED_tris = OUTPUT;
	Bat_Low_LED_tris = OUTPUT;
	Buzzer_tris = OUTPUT;
	Auto_Sw_tris = INPUT;
	Man_Sw_tris = INPUT;
	HB_LED_tris = OUTPUT;
	Vsel_tris = INPUT;
	Relay1_tris = OUTPUT;
	Relay1 = 0;					//Turn off Fan on startup
	Src_Relay_tris = OUTPUT;
	Src_Relay = 0;				//Open Src relay on startup
	Inv_Relay_tris = OUTPUT;
	Inverter_Relay = 0;			//Open Inverter relay on startup
	Fan_ena = 0;
	Buzzer = 0;					//Turn Buzzer off
	Beeper = 0;
	Ichg_sel1_tris = OUTPUT;
	Ichg_sel2_tris = INPUT;
	Vchg_sel1_tris = OUTPUT;
	Vchg_sel2_tris = INPUT;
	Tris_E0 = INPUT;			//E0, E1, D10, D8 are used for selecting parallel / 3 phase operation (On slave devices only)
	Tris_E1 = OUTPUT;			//Jumper between RE0 and RE1 = 1 phase (parallel) slave
	Tris_D10 = INPUT;			//Jumper between RE1 and RD10 = 3 phase operation, Inverter = Phase 2
	Tris_D8 = OUTPUT;			//Jumper between RD10 and RD8 = 3 phase operation, Inverter = Phase 3
								//Jumper between RE0 and RE1 and Jumper between RD10 and RD8 = Split phase operation (180 degree shift)
	
	U1MODE = 0;					//Disable UART1 (Sync pins are also UART1 pins)
	Master_Tris = OUTPUT;		//I/O pins used for synchronising machines
	Slave_Tris = INPUT;
		
	//Analog channels
	TRISBbits.TRISB0 = INPUT;
	TRISBbits.TRISB1 = INPUT;
	TRISBbits.TRISB2 = INPUT;
	TRISBbits.TRISB3 = INPUT;
	TRISBbits.TRISB4 = INPUT;
	TRISBbits.TRISB5 = INPUT;
	
	AD1PCFG = 0xFFC0;			//Select which Analog inputs are in analog mode (0 = analog, 1 = digital)
	
	//PWM error input
	Driver_Error_tris = INPUT;
	
	
}

void t_del(void)		//Small delay
{
	asm("NOP");
	asm("NOP");
	asm("NOP");
}

void get_master_phase(void)
{
	Master_Phase = Slave_RX;
	t_del();
	Master_Phase += Slave_RX;
	t_del();
	Master_Phase += Slave_RX;
	t_del();
	Master_Phase += Slave_RX;
	t_del();
	Master_Phase += Slave_RX;		//Best of 5
	
	if(Master_Phase > 2) Master_Phase = 1;
	else Master_Phase = 0;
}

void IO_test(void)			//Checks the state of the jumpers. Slightly complicated because jumpers connect two I/O pins together.
{							//This is because the LCD connector was re-purposed for jumpers.
	//Read charging current select jumper
	Ichg_sel1 = 1;
	t_del();
	if(Ichg_sel2 == 1) Ichg_max = Ichg_HI;		//Select High current charge mode
	else Ichg_max = Ichg_LO;		//Select Low current charge mode
	t_del();
	Ichg_sel1 = 0;
	t_del();
	if(Ichg_sel2 == 0)
	{
		if(Ichg_max == Ichg_HI) Ichg_max = Ichg_HI; //Confirm presence of jumper (No jumper = floating pin, could be high or low)
		else Ichg_max = Ichg_LO;
	}
	else Ichg_max = Ichg_LO;					//Select Low current charge mode
	
	//Read charging voltage select jumper
	Vchg_sel1 = 1;
	t_del();
	if(Vchg_sel2 == 1) Vchg_max = 1;			//Select higher voltage charge mode
	else Vchg_max = 0;			//Select lower voltage charge mode
	t_del();
	Vchg_sel1 = 0;
	t_del();
	if((Vchg_sel2 == 0) && (Vchg_max == 1)) Vchg_max = 1;	//Confirm presence of jumper (No jumper = floating pin, could be high or low)
	else Vchg_max = 0;							//Select lower voltage charge mode
	
	//Read System voltage select jumper.
	Vsel_tris = OUTPUT;
	Vsel_res = 0;
	t_del();
	Vsel_out = 1;					//Set Voltage select line high.
	for(del_cnt = 0; del_cnt < 250; del_cnt++)
	{
		t_del();						//Small delay to allow the cap to charge
	}
	Vsel_tris = INPUT;
	for(del_cnt = 0; del_cnt < 250; del_cnt++)
	{
		t_del();						//Small delay before reading the line
	}
	if(Vsel_jmp == 1) Vsel_res++;	//If voltage select line is high, increment result variable
	
	Vsel_tris = OUTPUT;
	t_del();
	Vsel_out = 0;					//Set Voltage select line low.
	for(del_cnt = 0; del_cnt < 250; del_cnt++)
	{
		t_del();						//Small delay to allow the cap to discharge
	}
	
	Vsel_out = 1;
	t_del();
	
	Vsel_tris = INPUT;
	for(del_cnt = 0; del_cnt < 1000; del_cnt++)
	{
		t_del();						//Small delay before reading the line
	}
	if(Vsel_jmp == 1) Vsel_res++;	//If voltage select line is high, increment result variable
	
	
	switch(Vsel_res)
	{
		case 0:							//Configured as a 36V machine
			Transformer_const = Transformer_const_36;
			VBat_high =	VBat_high_36;
			VBat_low = VBat_low_36;
			VBat_recon = VBat_recon_36;
			if(Vchg_max == 1) Vchg_max = Bulk36;
			else Vchg_max = Float36;
			VBat_freq_min = Bulk36;			//Maximum battery voltage where output frequency is still unchanged
			UART_printf("36V ");			//UART Not initialised yet, but buffer can hold 4 bytes, these will be sent once the UART is initialised	
			break;
		case 1:							//Configured as a 24V machine
			Transformer_const = Transformer_const_24;
			VBat_high =	VBat_high_24;
			VBat_low = VBat_low_24;
			VBat_recon = VBat_recon_24;
			if(Vchg_max == 1) Vchg_max = Bulk24;
			else Vchg_max = Float24;
			VBat_freq_min = Bulk24;			//Maximum battery voltage where output frequency is still unchanged
			UART_printf("24V ");			//UART Not initialised yet, but buffer can hold 4 bytes, these will be sent once the UART is initialised	
			break;
		case 2:							//Configured as a 48V machine
			Transformer_const = Transformer_const_48;
			VBat_high =	VBat_high_48;
			VBat_low = VBat_low_48;
			VBat_recon = VBat_recon_48;
			if(Vchg_max == 1) Vchg_max = Bulk48;
			else Vchg_max = Float48;
			VBat_freq_min = Bulk48;			//Maximum battery voltage where output frequency is still unchanged
			UART_printf("48V ");			//UART Not initialised yet, but buffer can hold 4 bytes, these will be sent once the UART is initialised	
			break;
	}		
	//Read Inverter mode select jumpers.
	//Jumper between RE0 and RE1 = 1 phase (parallel) slave
	//Jumper between RE1 and RD10 = 3 phase operation, Inverter = Phase 2
	//Jumper between RD10 and RD8 = 3 phase operation, Inverter = Phase 3
	//Jumper between RE0 and RE1 and Jumper between RD10 and RD8 = Split phase operation (180 degree shift)		
	Inv_Pos = 0;
	
	Tris_E1 = OUTPUT;
	Tris_E0 = INPUT;
	Tris_D10 = INPUT;
	t_del();
	Out_E1 = 1;
	t_del();
	if(In_E0 == 1) Inv_Pos |= 0b00000001;	//Bit 0 = 1 Phase Slave
	if(In_D10 == 1) Inv_Pos |= 0b00000010;	//Bit 1 = Phase 2 of 3 Phases
	t_del();	
	Out_E1 = 0;
	t_del();
	if((In_E0 == 0) && ((Inv_Pos & 0b00000001) == 1)) Inv_Pos |= 0b00000001; //Not really necessary, Inv_Pos already holds the correct value
	else Inv_Pos &= 0b11111110;
	if((In_D10 == 0) && ((Inv_Pos & 0b00000010) == 2)) Inv_Pos |= 0b00000010; //Not really necessary, Inv_Pos already holds the correct value
	else Inv_Pos &= 0b11111101;
	
	Tris_D8 = OUTPUT;
	t_del();
	Out_D8 = 1;
	t_del();
	if(In_D10 == 1) Inv_Pos |= 0b00000100;	//Bit 2 = Phase 3 of 3 Phases or Phase 2 of Split Phase
	t_del();
	Out_D8 = 0;
	t_del();
	if((In_D10 == 0) && ((Inv_Pos & 0b00000100) == 4)) Inv_Pos |= 0b00000100; //Not really necessary, Inv_Pos already holds the correct value
	else Inv_Pos &= 0b11111011;
}

//-----------------------------------------------------------------
//Protect the inverter from Overloads, Over temperature and battery low
//(Errors that don't need very quick reaction)
//This function is called once every second
//-----------------------------------------------------------------
void protection(void)
{
	
	//------------------------------------------------
	//Battery low protection
	//------------------------------------------------
	if((VBat < VBat_low) || (BatVVLow == 1))
	{
		Bat_low_beep = 1;						//Set flag to start beeping
		Bat_low_count += (VBat_low - VBat);		//The lower the voltage, the faster the turn-off
		if((Bat_low_count > UV_timeout) || (BatVVLow == 1))
		{
			Bat_low_count = UV_timeout + 1;
			Bat_UV = 1;							//Set battery low error flag
		}
	}
	else
	{
		Bat_low_beep = 0;
		Bat_low_count = 0;
		Beeper &= 0b01111111;	
	}
	
	//------------------------------------------------
	//Battery high protection
	//------------------------------------------------
	if((VBat > VBat_high) || (BatVVHigh == 1))
	{
		Bat_OV = 1;								//Set battery high error flag
	}
	
	//------------------------------------------------
	//Adjust output frequency with high battery voltage
	//------------------------------------------------
	if(VBat > VBat_freq_min)
	{
		VBat_freq_temp = VBat - VBat_freq_min;			//Difference between actual battery voltage and max. 50Hz voltage
		VBat_freq_temp1 = VBat_high - VBat_freq_min;	//Difference between 53Hz voltage and max. 50Hz voltage
		VBat_freq_temp2 = PR3_50Hz - PR3_53Hz;			//Difference between 50Hz period register and 53Hz period register
		VBat_freq_temp *= VBat_freq_temp2;				
		VBat_freq_temp /= VBat_freq_temp1;				//VBat_freq_temp now holds the amount by which the PR3 register must change
		
		PR3_calc = PR3_50Hz - VBat_freq_temp;			//Decreasing the period register increases the frequency

	}
	else
	{
		PR3_calc = PR3_50Hz;
	}

	//------------------------------------------------
	//Inverter Overload protection
	//------------------------------------------------
	if(Iac_RMS > Imax)
	{
		Red_LED |= 0b00000100;					//Turn on Overload LED while inverter is Overloaded
		Beeper |= 0b00000001;					//Turn on Buzzer while Inverter is overloaded
		Overload_count += (Iac_RMS - Imax);		//The higher the load, the faster the turn-off
	}
	else
	{
		if(Overload_count > 0) Overload_count--;
		if((Inv_OL == 0) && (Inv_SC == 0))
		{
			Red_LED &= 0b11111011;				//Turn off Overload LED if not overloaded
		}
		Beeper &= 0b11111110;				//Turn off Buzzer
	}
	
	if(Overload_count >= (Imax * 15))	//To allow 50% Overload for 30sec
	{
		PWM_off();						//Turn off PWM
		INV_MODE = INV_MODE_FAULT;
		Inv_OL = 1;						//Set overload Error flag
		Inv_OL_cnt++;					//Increment Overload counter (no. of recent overloads)
		Inv_OL_timeout = SC_timeout;	//Re-start inverter after SC_timeout seconds
		Overload_count = 0;
	}
	
	//----------------------------------------------------------------------------------------------------
	//Source Overload protection not needed, because Inverter overload protection protects the Source too.
	//----------------------------------------------------------------------------------------------------
	
	//------------------------------------------------
	//Over temperature protection
	//------------------------------------------------	
	if(Heatsink_temp > (Hs_temp_hi - 200))	//Fan comes on at 20 degrees below Over-temp
	{
		Fan_ena |= 0b00000010;			//Set Fan enable flag
		if(Heatsink_temp > Hs_temp_hi)
		{
			Inv_OT = 1;					//Set over temperature error flag
		}
	}
	else
	{
		Fan_ena &= 0b11111101;			//Clear Fan enable flag
	}
	
	//------------------------------------------------
	//Cooling fan control
	//Using Bit flags for fan enable, so that multiple
	//sources can request a fan enable, and all would
	//need to be removed before than fan can stop.
	//------------------------------------------------
	Power_VA = (unsigned long)(Iac_RMS);	//Calculate power in VA (RMS V x RMS A)
	Power_VA *= (unsigned long)(Vac_RMS);
	Power_VA /= (unsigned long)(1000); //Vac = 10x (1 decimal) and Iac is 100x (2 decimals)
	Pout = (unsigned int)(Power_VA);
		
	if(Power_VA > (Pmax / 2)) Fan_ena |= 0b00000001;	//Set Fan enable flag
	else Fan_ena &= 0b11111110;							//Clear fan enable flag
	
	if(Fan_ena > 0) Relay1 = 1;			//Turn on cooling fan if any flag is set
	else Relay1 = 0;					//Turn off cooling fan	if all flags are cleared
	
	
	//------------------------------------------------
	//If any error flags are set, then turn on
	//appropriate LED's and set INV_MODE.
	//Also recover from some errors if the error
	//condition is removed. (e.g. Batt low / high, Over temp)
	//------------------------------------------------
	if(Rev_PWR == 1)				//Reverse power fault (Source connected on Inverter output)
	{
		if((Red_LED & 0b00001000) != 0) Red_LED &= 0b11110111;	//Toggle Overload LED
		else Red_LED |= 0b00001000;
		if((Yellow_LED & 0b00000100) != 0) Yellow_LED &= 0b11111011; //Toggle Batt Low LED
		else Yellow_LED |= 0b00000100;
		if((Beeper & 0b00000010) != 0) Beeper &= 0b11111101; //Toggle Buzzer
		else Beeper |= 0b00000010;
		INV_MODE = INV_MODE_FAULT;
	}
	else
	{
		Red_LED &= 0b11110111;
		Yellow_LED &= 0b11111011;
		Beeper &= 0b11111101;
	}
	
	if(Bat_UV == 1)					//Battery Low Flag is set
	{
		Yellow_LED |= 0b00001000;	//Turn on Batt low LED
		if((Beeper & 0b00000100) != 0) Beeper &= 0b11111011; //Toggle Buzzer
		else Beeper |= 0b00000100;
		INV_MODE = INV_MODE_FAULT;
		if(VBat > VBat_recon)		//Recover from battery low
		{
			Bat_UV = 0;				//Clear battery low flag
		}
	}
	else
	{
		Yellow_LED &= 0b11110111;
		Beeper &= 0b11111011;
	}
	
	if(Bat_OV == 1)					//Battery High Flag is set
	{
		if((Red_LED & 0b00010000) != 0) Red_LED &= 0b11101111;	//Toggle Overload LED
		else Red_LED |= 0b00010000;
		if((Beeper & 0b00001000) != 0) Beeper &= 0b11110111; //Toggle Buzzer
		else Beeper |= 0b00001000;
		INV_MODE = INV_MODE_FAULT;
		if((VBat < VBat_high) && (BatVVHigh == 0))	//Recover from battery high
		{
			Bat_OV = 0;								//Clear battery high flag
		}
	}
	else
	{
		Red_LED &= 0b11101111;
		Beeper &= 0b11110111;
	}
			
	
	
	if(Inv_OT == 1)					//Over temperature Flag is set
	{
		if((Yellow_LED & 0b00010000) != 0) Yellow_LED &= 0b11101111; //Toggle Batt Low LED
		else Yellow_LED |= 0b00010000;
		if((Beeper & 0b00010000) != 0) Beeper &= 0b11101111; //Toggle Buzzer
		else Beeper |= 0b00010000;
		INV_MODE = INV_MODE_FAULT;
		if(Heatsink_temp < Hs_temp_rec) Inv_OT = 0;		//Recover from over temperature error, clear Over temp. flag	
	}
	else
	{
		Yellow_LED &= 0b11101111;
		Beeper &= 0b11101111;
	}

	if(Inv_OL == 1)					//Overload Flag is set
	{
		Red_LED |= 0b00000100;		//Overload LED steadily lit if Overload
		if((Beeper & 0b00100000) != 0) Beeper &= 0b11011111; //Toggle Buzzer
		else Beeper |= 0b00100000;
		Inv_OL_reset = 0;			//Re-start overload fault clearing timer
		if(Inv_OL_timeout > 0) Inv_OL_timeout--;
		else
		{
			if(Inv_OL_cnt < 3) Inv_OL = 0;		//Recover from Overload if fewer than three have occurred in the last 2 minutes
		}
	}
	else
	{
		if(Inv_OL_reset < 120) Inv_OL_reset++;	//Clear overload count after 2 minutes (Allows 3 overloads in 2 minutes)
		else Inv_OL_cnt = 0;
		//Red_LED &= 0b11111011;
		Beeper &= 0b11011111;
	}
	
	if(Inv_SC == 1)								//Short Circuit Flag is set
	{
		Red_LED |= 0b00000100;		//Overload LED steadily lit if Short Circuit
		if((Beeper & 0b01000000) != 0) Beeper &= 0b10111111; //Toggle Buzzer
		else Beeper |= 0b01000000;
		INV_MODE = INV_MODE_FAULT;
		Inv_SC_reset = 0;						//Re-start 1 minute timer
		if(Inv_SC_timeout > 0) Inv_SC_timeout--;
		else
		{
			if(Inv_SC_cnt < 3) Inv_SC = 0;		//Recover from Short Cct if fewer than 3 have occurred in the last 2 minutes	
		}
	}
	else
	{
		if(Inv_SC_reset < 120) Inv_SC_reset++;	//Clear Short circuit count after 2 minutes (Allow 3 shorts in 2 minutes)
		else Inv_SC_cnt = 0;
		Red_LED &= 0b11011111;
		Beeper &= 0b10111111;
	}
}
//----------------------------------------------------------------------------
//End of protection
//----------------------------------------------------------------------------


//----------------------------------------------------------------------------
//Enable the Interrupt on change function for RC14
//RC14 is the MOSFET error input, which is activated by the protection
//on the drivers. The interrupt priority is set to the second highest
//possible value, second only to internal CPU interrupts
//----------------------------------------------------------------------------
void PWM_Error_Init(void)
{
	CNEN1bits.CN0IE = 1;	//Enable interrupt on change for CN0 input (RC14)
	CNPU1bits.CN0PUE = 1;	//Enable internal pullup on CN0 input
	IFS1bits.CNIF = 0;		//Clear Change notification interrupt flag
	IPC4bits.CNIP = 6;		//Set Interrupt on change Interrupt priority (Second highest possible priority)
	IEC1bits.CNIE = 1;		//Enable Interrupt on change
}

//-----------------------------------------------------------------
//Main
//-----------------------------------------------------------------
int main(void) {
	
	RCONbits.SWDTEN = 0;		// Disable Watch Dog Timer	

	IO_Init();			//Configure I/O pins
	
	//Initialise variables
	Sin_pos = 0;
	cycle_cnt = 0;
	Sin_val = 768;
	Sin_180 = 256;
	amplitude = 0;
	Timer_1ms = 0 ;
	Dbg_Start = 0;
	Dbg_Len = 0;
	Debug_cmd = 0;
	pwm_error = 0;
	Error_count = 0;
	Inv_SC_cnt = 0;
	Inv_SC_timeout = 0;
	Inv_OL_cnt = 0;
	Inv_OL_timeout = 0;
	PWMoffCnt = 0;
	Pout_sum = 0;
	Ramp_count = 0;
	Zero_cross = 0;
	Inv_sync = 0;
	Src_rec = 0;
	Stop_feedback = 0;
	Master_period = 0;
	Phase_Inc = 0;
	Phase_Mult = 1;
	Vinc = 2;
	Slave_Cyc = 0;
	PF_Cyc = 0;
	
	Vac_AVG = 2048;		//For approximately a 1.65V offset. (To reduce initial error if value starts at 0)

	SYS_MODE = SYSTEM_MODE_OFF;
	INV_MODE = INV_MODE_STOPPED;
	
	DataEEInit();		//Initialise Flash EEPROM emulation
	Read_cal_flash();	//Read calibration values from flash memory
	
	UART_Init();		//Initialise serial comms (115200 8-n-1)
	
	IO_test();			//Temporary
	
	Debug_sys_init();	//Display some debug info on startup
	
	Debug_Inv_Mode(Inv_Pos);	//Display Jumper selections on startup
	
	Sw_freq_calc();		//Calculate all values that depend on the switching frequency	
	
	VBat = VBat_low;	//Start with non-zero Battery volts So that it doesn't get a batt low error on startup

	ADC_Init();			//Setup ADC
	Timer4_Init();		//Setup Timer 4 operation
	Timer3_Init();		//Setup Timer 3 operation
	
	PWM_Init();			//Initialise PWM
	PWM_off();			//Turn off PWM
	
	PWM_Error_Init();	//Enable the PWM error interrupt
		
	Timer_1ms = 1;
	
	//Endless loop
	while(1)
	{
		if(Debug_cmd > 0)
		{
			Parse_debug_buffer();		//If there was a debug command, service it
			Debug_cmd--;
		}
		
		if((Timer_1ms % 1000) == 0)		//This happens every second
		{
			Timer_1ms++;				//Just to stop this happening more than once a second
			HB_LED ^= 1;				//Toggle Heartbeat LED every second
			protection();				//Check for Overload, Over temp. and Battery low errors
			if((INV_MODE != INV_MODE_STOP_CHG) && (SYS_MODE != SYSTEM_MODE_OFF) && (INV_MODE != INV_MODE_CHARGING) && (Source_in_spec > 40) && (Src_spec_cnt < 10)) Src_spec_cnt++;	//Source must be in spec for 10 seconds
			else Src_spec_cnt = 0;	
			Source_in_spec = 0;			//Reset source_in_spec counter (Counts every cycle that the source is in spec)		
			if((Src_spec_cnt == 10) && (INV_MODE != INV_MODE_CHARGING) && (SYS_MODE != SYSTEM_MODE_OFF)) INV_MODE = INV_MODE_REQ_CHARGE;
			if(INV_MODE == INV_MODE_CHARGING)
			{
				if((Green_LED & 0b00000001) != 0) Green_LED &= 0b11111110;	//Toggle Inverter LED every second while charging
				else Green_LED |= 0b00000001;
			}
			else Green_LED &= 0b11111110;
		}

		if(INV_MODE == INV_MODE_FAULT)
		{
			if((Rev_PWR == 0) && (Bat_UV == 0) && (Inv_OL == 0) && (Inv_SC == 0) && (Inv_OT == 0) && (Bat_OV == 0))	//Recover from a fault
			{
				INV_MODE = INV_MODE_STOPPED;
			}
		}
		
		if(Green_LED == 0) Inv_LED = 0;
		else Inv_LED = 1;
		
		if(Yellow_LED == 0) Bat_Low_LED = 0;
		else Bat_Low_LED = 1;
		
		if(Red_LED == 0) OL_LED = 0;
		else OL_LED = 1;
		
		if(Beeper == 0) Buzzer = 0;
		else Buzzer = 1;
	}  
	return 0;
} 

//-----------------------------------------------------------------
// All the Interrupt service routines follow
//-----------------------------------------------------------------

//-----------------------------------------------------------------
// Timer2 ISR:
// This is the PWM timer interrupt.
//-----------------------------------------------------------------
void __attribute__ ((interrupt,no_auto_psv)) _T2Interrupt(void)
{
	IFS0bits.T2IF = 0;	//Clear TImer 2 Interrupt flag
	//AD1CON1bits.SAMP = 1;	//Start Next A/D conversion
	
	if((INV_MODE == INV_MODE_RAMP_UP) || (INV_MODE == INV_MODE_RUNNING) || (INV_MODE == INV_MODE_STOPPED) || (INV_MODE == INV_MODE_REQ_CHARGE))
	{
		OC1R = (PWM_Period - Sin_val) + dead_time;	//Sets the time of the rising edge
		OC1RS = Sin_val - dead_time;				//Sets the time of the falling edge
	
		OC2RS = (PWM_Period - Sin_val) - dead_time;	//This is the inverse of PWM1
		OC2R = Sin_val + dead_time;
	
		
		OC3R = (PWM_Period - Sin_180) + dead_time;	//Sets the time of the rising edge
		OC3RS = Sin_180 - dead_time;				//Sets the time of the falling edge
	
		OC4RS = (PWM_Period - Sin_180) - dead_time;	//This is the inverse of PWM3
		OC4R = Sin_180 + dead_time;
	}
	
	if(INV_MODE == INV_MODE_CHARGING)
	{
		OC2RS = PWM_charge;			//Set output duty cycle in charging mode
		OC4RS = PWM_charge;	
	}
	
	if(pwm_error == 1)			//There was an error from the FET drivers
	{
		pwm_error = 0;
		Error_count++;			//Count the number of pwm errors
	}

}

//-----------------------------------------------------------------
// Change notification ISR:
// This is the PWM error interrupt.
//-----------------------------------------------------------------
void __attribute__ ((interrupt,no_auto_psv)) _CNInterrupt(void)
{
	if(Driver_Error == 0) 	//a PWM error has occurred
	{
		pwm_error = 1;		//Set pwm error flag
	}
	IFS1bits.CNIF = 0;		//Clear Change notification Interrupt flag
}

//-----------------------------------------------------------------
// Timer3 ISR:
// (128 interrupts per 50Hz cycle)
//-----------------------------------------------------------------
void __attribute__ ((interrupt,no_auto_psv)) _T3Interrupt(void)
{
	IFS0bits.T3IF = 0;	//Clear TImer 3 Interrupt flag
	Sin_pos+=64;		//Increment offset in Sine table (Was 8 with Sine1024)
	Sin_pos %= 8192;	//Mod with no. of values in Sine Table
	
	PWM_Temp1 = (s32)(Sine[Sin_pos]);	//Get new value from sine lookup table
			
	PWM_Temp2 = PWM_Temp1 * (s32)(amplitude);	//Scale sine value by amplitude
		
	if(PWM_Temp2 > (s32)(PWM_limit)) PWM_Temp2 = (s32)(PWM_limit);		//Set Limits to 95% of maximum
	if(PWM_Temp2 < (s32)(-PWM_limit)) PWM_Temp2 = (s32)(-PWM_limit);	//for Protection on drivers to work
		
	PWM_Temp1 = -PWM_Temp2;		//One Sine Reference is the inverse of the other
	
	PWM_Temp1 += PWM_offset;	//Add offset to remove negative values
	PWM_Temp2 += PWM_offset;
		
	PWM_Temp3 = (u32)(PWM_Temp1);	
	PWM_Temp4 = (u32)(PWM_Temp2);	
		
	PWM_Temp3 >>= 11;		//This puts the values back into the range (period / 2) -> period
	PWM_Temp4 >>= 11;		
		
	//Note: For Unipolar switching, the pwm pulses should be centered around 512
	//so they are made to fit in the 512..1023 range, and then 'mirrored' around 512
	//The mirroring is done in the PWM interrupts
	
	Sin_val = (unsigned int)(PWM_Temp3);
	Sin_180 = (unsigned int)(PWM_Temp4);
	
	ADC_measure_all();	//Measure all ADC values once each interrupt (128 times per cycle)

	if(INV_MODE == INV_MODE_RUNNING)
	{	
		switch(Inv_Pos)		//The value in Inv_Pos tells us if the Inverter is a master or slave
		{
			case 0:		//Inverter is the Master (default configuration)
				if(INV_MODE == INV_MODE_RUNNING)
				{
					Master_period++;
					if((Inv_Zero_Cross == 0) && (Master_Sync == 0))
					{
						Master_Sync_offset = Sin_pos;
						Master_Sync = 1;
						Master_period = 0;
					}
					if((Sin_pos == Master_Sync_offset) || (Master_period == 128))
					{
						Master_TX = 1;	//Zero crossing low to high
						Master_period = 0;
					}
					if(Inverter_Load > 120) Inverter_Load = 120;
					if(Master_period == (4 + Inverter_Load)) Master_TX = 0;
				}
				break;
			
			case 1:		//Inverter is a slave in a single phase installation (parallel operation)
				Master_period++;
				get_master_phase();
				
				if((Master_Phase == 0) && (Master_Phase_Old == 1))					//End of high pulse from master
				{
					if(Master_period > 4) Master_Load = Master_period - 4;			//Rough idea of master's load status
					else Master_Load = 0;
				}
				
				
				if((Master_Phase == 1) && (Master_Phase_Old == 0))		//Master had a Zero crossing
				{
					if((Master_period > 126) && (Master_period < 130))	//Inverter and Master have same frequency
					{
						if(Master_Sync == 65)
						{
							Slave_Cyc++;
							PF_Cyc++;
								
							Inverter_Relay = 1;				//Close Inverter relay
							
							//This section of code is run every 161 cycles when synced to a master inverter
							//and attempts to maximise the power factor by adjusting the output voltage.
							//The direction of power flow is ignored, since the CT orientation is unknown

							if(PoutW > 0) Inverter_PF = PoutW;
							else Inverter_PF = -PoutW;
							Inverter_PF <<= 2;											//Multiply by 4 for better resolution (Should be * 100 but would need a 32 bit variable)
							Inverter_PF /= (Power_VA >> 4);								//Power factor 0..1 = 0..64;
							Inverter_PF_Sum += Inverter_PF;								//Get the average power factor over 50 cycles
							
							if(PF_Cyc == 161)
							{
								PF_Cyc = 0;
								Inverter_PF_Sum >>= 7;									//Summed over 161 cycles / 128 makes 0..80 range
								if(Inverter_PF_Sum < Inverter_PF_Old) Vinc = -Vinc;		//Try to maximise Power factor
								Vout += Vinc;											//by adjusting the output voltage
								if(Vout > 2400) Vout = 2400;							//Apply limits to output voltage
								if(Vout < 2200) Vout = 2200;
								Inverter_PF_Old = Inverter_PF_Sum;
								Inverter_PF_Sum = 0;
							}
							
							//Attempt to get the master and slave to share the load.
							//Each one should take a percentage of the load, proportional
							//to their capacity, so that inverters of different capacities
							//can be paralleled.	
							Inverter_Load_Sum += Inverter_Load;
							Master_Load_Sum += Master_Load;
							
							if(Slave_Cyc == 16)											//Adjust phase every 16 cycles				
							{
								Slave_Cyc = 0;
								Inverter_Load_Sum >>= 4;								//Average loading over 16 cycles
								Master_Load_Sum >>= 4;
								
								Inv_Load_T = Inverter_Load_Sum;							//Just for debug, to see the relative
								Mstr_Load_T = Master_Load_Sum;							//loading of the inverters
								
								if(Inverter_Load_Sum > Master_Load_Sum)					//Always trying to minimise the load
								{														//on the Inverter that has the highest load
									Highest_Load = Inverter_Load_Sum;					//should spread the load equally between
								}														//the master and slave
								else
								{
									Highest_Load = Master_Load_Sum;
								}
								
								if(Highest_Load > Highest_Load_Old)
								{
									Phase_Mult = -Phase_Mult;
								}
								
								Phase_Inc += Phase_Mult;
								
								Highest_Load_Old = Highest_Load;

								Inverter_Load_Sum = 0;
								Master_Load_Sum = 0;
								//Sine table has 8192 values for 360 degrees, set the phase limits to reasonable values
								if(Phase_Inc > 250) Phase_Inc = 250;
								if(Phase_Inc < -100) Phase_Inc = -100;
								Phase_offset = (unsigned int)(Phase_Inc + 4000);		//Only used for debug
							}
							Sin_pos = Master_Sync_offset;	//re-sync with master every zero-crossing
							Sin_pos += Phase_Inc;			//Shift inverter phase by amount in Phase_Inc
							Stop_feedback = 5;				//Disable AC voltage feedback while synced (and for 5 cycles after)	
						}
					}
					else
					{
						Slave_Cyc = 0;
						PF_Cyc = 0;
						Inverter_Load_Sum = 0;
						Master_Load_Sum = 0;
						Inverter_PF_Sum = 0;
						Inverter_Relay = 0;				//Open Inverter relay
					}	
					
					if((Master_period == 128) && (Inv_Zero_Cross == 0) && (Master_Sync < 64)) //Inverter and Master synced
					{
						if(Master_Sync == 0) Master_Sync_offset = Sin_pos;
						else Master_Sync_offset += Sin_pos;
						Master_Sync++;
					}
					if(Master_Sync == 64)
					{
						Master_Sync_offset >>= 6;
						Master_Sync++;
					}
					if((Inv_Zero_Cross > 0) && (Inv_Zero_Cross < 64) && (Master_Sync == 0))
					{
						Sin_pos-=8;									//Shift Inverter phase slightly
						if(Inv_Zero_Cross > 2) Sin_pos-=32;
						Inverter_Relay = 0;							//Open Inverter Relay
					}
					if((Inv_Zero_Cross > 63) && (Master_Sync == 0))
					{
						Sin_pos+=8;									//Shift Inverter phase slightly
						if(Inv_Zero_Cross > 65) Sin_pos+=32;
						Inverter_Relay = 0;							//Open Inverter Relay
					}
					
					if(Master_period > 128)		//Inverter frequency too high
					{
						if(PR3 < 2980) PR3++;	//Decrease inverter frequency	
					}
					if(Master_period < 128)		//Inverter frequency too low
					{
						if(PR3 > 1893) PR3--;	//Increase inverter frequency	
					}
					Master_period = 0;	
				}
				Master_Phase_Old = Master_Phase;
				
				if(Master_period > 256)			//Seems that Master has disappeared
				{
					Slave_Cyc = 0;
					PF_Cyc = 0;
					Inverter_Load_Sum = 0;
					Master_Load_Sum = 0;
					Inverter_PF_Sum = 0;
					Inverter_Relay = 0;				//Open Inverter relay	
				}
				break;
					
			case 2:		//Inverter is Phase 2 in a 3 Phase installation
				Master_period++;
				Master_Phase = Slave_RX;
				
				if((Master_period == 42) && (Master_Freq_Sync == 1))	//Inverter and Master have same frequency
				{
						if((Inv_Zero_Cross < 4) || (Inv_Zero_Cross > 124)) //Inverter and Master synced
						{
							Master_Sync = 1;
							Master_Sync_offset = Sin_pos;
							Inverter_Relay = 1;							//Close Inverter relay
						}
						else
						{
								Master_Sync = 0;							//Frequency correct, but not phase
								Inverter_Relay = 0;							//Open Inverter Relay
						}
						if((Inv_Zero_Cross > 0) && (Inv_Zero_Cross < 64)) Sin_pos-=32;	//Shift Inverter phase slightly
						if(Inv_Zero_Cross > 63) Sin_pos+=32;							//Shift Inverter phase slightly
				}
				
				if((Master_Phase == 1) && (Master_Phase_Old == 0))		//Master had a Zero crossing
				{
					if((Master_period > 126) && (Master_period < 130))	//Inverter and Master have same frequency
					{
						Master_Freq_Sync = 1;	
					}
					else Master_Freq_Sync = 0;
					if(Master_period > 128)		//Inverter frequency too high
					{
						if(PR3 < 2980) PR3++;				//Decrease inverter frequency
					}
					if(Master_period < 128)		//Inverter frequency too low
					{
						if(PR3 > 1893) PR3--;				//Increase inverter frequency	
					}
					Master_period = 0;	
				}
				Master_Phase_Old = Master_Phase;
				
				if(Master_period > 256)			//Seems that Master has disappeared
				{
					Master_Sync = 0;
					Master_Freq_Sync = 0;
					Inverter_Relay = 0;
				}
				
				break;
					
			case 4:		//Inverter is Phase 3 in a 3 Phase installation
				Master_period++;
				Master_Phase = Slave_RX;
				
				if((Master_period == 85) && (Master_Freq_Sync == 1))	//Inverter and Master have same frequency
				{
						if((Inv_Zero_Cross < 4) || (Inv_Zero_Cross > 124)) //Inverter and Master synced
						{
							Master_Sync = 1;
							Master_Sync_offset = Sin_pos;
							Inverter_Relay = 1;							//Close Inverter relay
						}
						else
						{
								Master_Sync = 0;										//Frequency correct, but not phase
								Inverter_Relay = 0;										//Open Inverter Relay
						}
						if((Inv_Zero_Cross > 0) && (Inv_Zero_Cross < 64)) Sin_pos-=32;	//Shift Inverter phase slightly
						if(Inv_Zero_Cross > 63) Sin_pos+=32;							//Shift Inverter phase slightly
				}
				
				if((Master_Phase == 1) && (Master_Phase_Old == 0))		//Master had a Zero crossing
				{
					if((Master_period > 126) && (Master_period < 130))	//Inverter and Master have same frequency
					{
						Master_Freq_Sync = 1;	
					}
					else Master_Freq_Sync = 0;
					if(Master_period > 128)					//Inverter frequency too high
					{
						if(PR3 < 2980) PR3++;				//Decrease inverter frequency
					}
					if(Master_period < 128)					//Inverter frequency too low
					{
						if(PR3 > 1893) PR3--;				//Increase inverter frequency	
					}
					Master_period = 0;	
				}
				Master_Phase_Old = Master_Phase;
				
				if(Master_period > 256)			//Seems that Master has disappeared
				{
					Master_Sync = 0;
					Master_Freq_Sync = 0;
					Inverter_Relay = 0;
				}
					
				break;
					
			case 5:		//Inverter is Phase 2 in a Split Phase installation
				Master_period++;
				Master_Phase = Slave_RX;
				
				if((Master_period == 64) && (Master_Freq_Sync == 1))	//Inverter and Master have same frequency
				{
						if((Inv_Zero_Cross < 4) || (Inv_Zero_Cross > 124)) //Inverter and Master synced
						{
							Master_Sync = 1;
							Master_Sync_offset = Sin_pos;
							Inverter_Relay = 1;							//Close Inverter relay
						}
						else
						{
								Master_Sync = 0;										//Frequency correct, but not phase
								Inverter_Relay = 0;										//Open Inverter Relay
						}
						if((Inv_Zero_Cross > 0) && (Inv_Zero_Cross < 64)) Sin_pos-=32;	//Shift Inverter phase slightly
						if(Inv_Zero_Cross > 63) Sin_pos+=32;							//Shift Inverter phase slightly
				}
				
				if((Master_Phase == 1) && (Master_Phase_Old == 0))		//Master had a Zero crossing
				{
					if((Master_period > 126) && (Master_period < 130))	//Inverter and Master have same frequency
					{
						Master_Freq_Sync = 1;	
					}
					else Master_Freq_Sync = 0;
					if(Master_period > 128)					//Inverter frequency too high
					{
						if(PR3 < 2980) PR3++;				//Decrease inverter frequency
					}
					if(Master_period < 128)					//Inverter frequency too low
					{
						if(PR3 > 1893) PR3--;				//Increase inverter frequency	
					}
					Master_period = 0;	
				}
				Master_Phase_Old = Master_Phase;
				
				if(Master_period > 256)			//Seems that Master has disappeared
				{
					Master_Sync = 0;
					Master_Freq_Sync = 0;
					Inverter_Relay = 0;
				}
				
				break;	
	
			default:
				break;			
		}
	}
	
	if(INV_MODE == INV_MODE_REQ_CHARGE)
	{
		Src_period++;
		
		if(Zero_cross == 1)
		{
			if((Inv_sync == 1) && (Freq_sync == 1))
			{
				Inv_in_sync = 1;
				Sync_offset = Sin_pos;	//Used to recover from grid failure later
			}
			else Inv_in_sync = 0;
			
			if(Src_period > 129)	//Invereter frequency too high
			{
				Freq_sync = 0;
				if(PR3 < 2980) PR3+=5;				//Decrease inverter frequency
			}
			
			if(Src_period < 127)	//Inverter frequency too low
			{
				Freq_sync = 0;
				if(PR3 > 1893) PR3-=5;				//Increase inverter frequency
			}
			
			if((Src_period > 126) && (Src_period < 130)) Freq_sync = 1;
			
			if(VInv_Src_temp > 0) Sin_pos++;
				
			if(VInv_Src_temp < 0) Sin_pos--;
			
			Src_period = 0;
		}		
	}
	else
	{
		if(INV_MODE == INV_MODE_CHARGING)
		{
			Src_period++;
			
			if(Zero_cross == 1)
			{
				if(Src_period > 128) 						//Invereter frequency too high
				{
					PR3+=20;								//Decrease inverter frequency
					if(Src_period > 129) PR3+=20;
					if(Src_period > 130) PR3+=20;
					if(Src_period > 131) PR3+=20;
					if(PR3 > 3100) INV_MODE = INV_MODE_SRC_REC;		//Source frequency too low	
					Sin_pos = Sync_offset;
				}
				
				if(Src_period < 128)						//Inverter frequency too low
				{
					if(PR3 > 1893) PR3-=5;					//Increase inverter frequency
					if(Src_period > 125) Sin_pos = Sync_offset;
				}
				Src_period = 0;
				
				if(Src_period == 128)
				{
					Sin_pos = Sync_offset;
				}
			}
		}
		else
		{
			Src_period = 0;
			Inv_sync = 0;
			Freq_sync = 0;
			Inv_in_sync = 0;
			Sync_offset = 0;
		}	
	}
	
	if(BatVVHigh == 1)
	{
		 PWM_charge = 0;	//Set duty cycle to 0 on Overvoltage
		 INV_MODE = INV_MODE_FAULT;
		 Bat_OV = 1;
	}
	if(BatVVLow == 1)
	{
		 PWM_charge = 0;	//Set duty cycle to 0 on Overvoltage
		 INV_MODE = INV_MODE_FAULT;
		 Bat_UV = 1;
	}
}

//-----------------------------------------------------------------
// Timer4 ISR:
// Timer4 is set up to interrupt every 1mS
//-----------------------------------------------------------------
void __attribute__ ((interrupt,no_auto_psv)) _T4Interrupt(void)
{
	IFS1bits.T4IF = 0;	//Clear TImer 4 Interrupt flag
	Timer_1ms++;
	Timer_1ms %= 65000;
	
	if((Timer_1ms % 20) == 0)	//Approx. every cycle (20mS)
	{
		
		if((INV_MODE == INV_MODE_RUNNING) && (Inv_Pos == 0))
		{
			if(PR3 < PR3_calc) PR3++;
			if(PR3 > PR3_calc) PR3--;	
		}
		
		if(Error_count > Error_thresh)	//If there were enough PWM errors in the last 20ms then there was a fault
		{
			Timer_PWM_error+=2;			//Counts the number of cycles with faults
			if(Timer_PWM_error >= 398)	//Inverter has had a continuous short for about 2 seconds
			{
				PWM_off();						//Turn off PWM
				INV_MODE = INV_MODE_FAULT;
				Inv_SC = 1;						//Short CCT error flag
				Inv_SC_cnt++;					//Increment short circuit count (no. of recent shorts)
				Inv_SC_timeout = SC_timeout;	//Set time until restart
				Timer_PWM_error = 0;
			}	
		}
		else
		{
			if(Timer_PWM_error > 0)	Timer_PWM_error--;	//So that shorts of small duration eventually clear
		}
		Error_count = 0;
		
		if((Bat_low_beep == 1) && ((Timer_1ms % 200) == 0) && (Bat_UV == 0))	//Toggle Buzzer 6 times at 400ms intervals, every second while Batt volts is low.
		{
			if((Beeper & 0b10000000) != 0) Beeper &= 0b01111111; //Toggle Buzzer
			else Beeper |= 0b10000000;
			Beep_count++;
			if(Beep_count == 6)
			{
				Bat_low_beep = 0;
				Beep_count = 0;	
			}	
		}
		
		if(Source_chg_dropout == 1)					//Source dropped out within first 5 minutes of charging
		{
			Source_reconnect_timer++;
			if(Source_reconnect_timer > 5000)		//Source did not reconnect within 5 seconds
			{
				Source_chg_dropout = 0;
				Source_reconnect_timer = 0;
			}
		}
		
		if((Vsrc_RMS > 1700) && (Vsrc_RMS < 2900))		//Source voltage in spec
		{
			Source_in_spec++;							//Increment in-spec timer;
			Source_is_in_spec = 1;
			if((Source_chg_dropout == 1) && (Source_reconnect_timer < 5000))
			{
				Ichg_max /= 2;					//Halve target charging current
			}
			Source_chg_dropout = 0;
			Source_reconnect_timer = 0;
			Sag_count = 0;
		}
		else
		{
			Source_in_spec = 0;
			if((INV_MODE == INV_MODE_REQ_CHARGE) || (INV_MODE == INV_MODE_CHARGING) || (INV_MODE == INV_MODE_STOP_CHG))
			{
				if((Timer_1ms % 2000) == 0)						//Flash Yellow LED every 2 seconds;
				{
					Yellow_LED |= 0b00100000;
					LED_timer = Timer_1ms + 300;	 
				}
				if(Timer_1ms == LED_timer) Yellow_LED &= 0b11011111;
				
				if((Parallel_timer_sec > 0) && (Parallel_timer_sec < 300))		//Source has dropped out during first 5 minutes of charging
				{
					Source_chg_dropout = 1;	
				}
				if((Vsrc_RMS > Vsrc_VVLow) && (Vsrc_RMS < 1700))	//Low voltage dip
				{
					Sag_count++;
					if(Sag_count > 1000)					//Must disconnect after 1s
					{
						INV_MODE = INV_MODE_SRC_REC;
					}
				}
				else										//Completely out of range
				{
					INV_MODE = INV_MODE_SRC_REC;
				}
			
			}
			else
			{
				Yellow_LED &= 0b11011111;
				if((Vsrc_RMS > Vsrc_VVLow) && (Vsrc_RMS < 1700))	//Source present, but out of range
				{
					Flash_count++;
					if(Flash_count == 1000)
					{
						Flash_count = 0;
						LEDs ^= 1;			//Toggle all LEDs at about 1Hz
						if(LEDs == 1)
						{
							Green_LED |= 0b00000010;
							Yellow_LED |= 0b00000001;
							Red_LED |= 0b00000001;	
						}
						else
						{
							Green_LED &= 0b11111101;
							Yellow_LED &= 0b11111110;
							Red_LED &= 0b11111110;	
						}	
					}
				}
				else
				{
					Green_LED &= 0b11111101;
					Yellow_LED &= 0b11111110;
					Red_LED &= 0b11111110;	
				}	
			}			
		}
	}

	
	
	if(PoutW < 0) Pout_abs = -PoutW;	//Pout_abs is used for load sensing so that it works even if the CT is backwards
	else Pout_abs = PoutW;

	
	//Check status of auto / manual / off switch
	if(Auto_Sw == 0) Auto_Sw_count++;
	else
	{
		if(Auto_Sw_count > 0) Auto_Sw_count--;
	}
		
	if(Auto_Sw_count > Button_delay) Auto_Sw_count = Button_delay + 1;
	
	if(Man_Sw == 0) Man_Sw_count++;
	else
	{
		if(Man_Sw_count > 0) Man_Sw_count--;
	}
		
	if(Man_Sw_count > Button_delay) Man_Sw_count = Button_delay + 1;
	
	switch(SYS_MODE)			//Sys_mode is selected by the rocker switch (Off, Manual, Auto)
	{
		case SYSTEM_MODE_OFF:
			if(Vac_RMS > 300) Rev_PWR = 1;		//If there is > 30V on the inv. output while off, then set the error flag
			else Rev_PWR = 0;
			if(INV_MODE != INV_MODE_STOPPED)
			{
				INV_MODE = INV_MODE_STOPPED;
			}
			if((Auto_Sw_count > Button_delay) && (Rev_PWR == 0))	//Switch has been put into Auto position
			{
				UART_printf("Changed to Auto Mode\r");
				SYS_MODE = SYSTEM_MODE_AUTO;
			}
			if((Man_Sw_count > Button_delay) && (Rev_PWR == 0))		//Switch has been put into Manual position
			{
				UART_printf("Changed to Manual Mode\r");
				SYS_MODE = SYSTEM_MODE_MAN;
			}
			if((Timer_1ms % 2000) == 0)		//Cycle LED's while in System Off mode to indicate Power is present
			{
				Red_LED |= 0b00000010;
				Yellow_LED &= 0b11111101;
				Green_LED &= 0b11111011;
				LED_timer = Timer_1ms + 667;
			}
			if(Timer_1ms == LED_timer)
			{
				if((Red_LED & 0b00000010) != 0)
				{
					Red_LED &= 0b11111101;
					Yellow_LED |= 0b00000010;
					Green_LED &= 0b11111011;
					LED_timer = Timer_1ms + 667;
				}
				else
				{
					Red_LED &= 0b11111101;
					Yellow_LED &= 0b11111101;
					Green_LED |= 0b00000100;
				}
			}
			break;
		case SYSTEM_MODE_MAN:
			if(INV_MODE == INV_MODE_STOPPED)
			{
				PWM_on();
				INV_MODE = INV_MODE_RAMP_UP;
			}
			if(Auto_Sw_count > Button_delay)
			{
				UART_printf("Changed to Auto Mode\r");
				SYS_MODE = SYSTEM_MODE_AUTO;
			}
			else
			{
				if((Auto_Sw_count == 0) && (Man_Sw_count == 0)) //Rocker Switch is in the off position
				{
					UART_printf("Changed to Off Mode\r");
					SYS_MODE = SYSTEM_MODE_OFF;	
				}
			}
			Red_LED &= 0b11111101;
			Yellow_LED &= 0b11111101;
			Green_LED &= 0b11111011;
			break;
		case SYSTEM_MODE_AUTO:
			if((INV_MODE == INV_MODE_STOPPED) && (Sense_count > Sense_time))
			{
				PWM_on();
				INV_MODE = INV_MODE_RAMP_UP;
				Sense_count = 0;
			}
			if((INV_MODE == INV_MODE_RUNNING) && (Sense_count > Sense_off_time))	//Not enough load, go back to load sensing
			{
				INV_MODE = INV_MODE_STOPPED;
				Sense_count = 0;
			}
			if(Man_Sw_count > Button_delay)
			{
				UART_printf("Changed to Manual Mode\r");
				SYS_MODE = SYSTEM_MODE_MAN;
			}
			else
			{
				if((Auto_Sw_count == 0) && (Man_Sw_count == 0)) //Rocker Switch is in the off position
				{
					UART_printf("Changed to Off Mode\r");
					SYS_MODE = SYSTEM_MODE_OFF;	
				}
			}
			Red_LED &= 0b11111101;
			Yellow_LED &= 0b11111101;
			Green_LED &= 0b11111011;
			break;	
	}
	
	Sense_count++;
	if(Sense_count > 60000) Sense_count = 60001;
	
	switch(INV_MODE)
	{
		case INV_MODE_STOPPED:	//In Stopped mode, the Inverter must be switched off
			if(amplitude > 50) amplitude -= 50;
			Src_Relay = 0;
			Inverter_Relay = 0;
			Master_Sync = 0;
			Master_period = 0;
			PWMoffCnt++;
			if(PWMoffCnt > 20)
			{
				PWM_off();
				Green_LED &= 0b11110111;
				PWMoffCnt = 0;
				amplitude = 0;
			}
			break;
		case INV_MODE_RAMP_UP:
			if(amplitude < Ramp_max)
			{
				amplitude++; //Do linear ramp-up to approximately the correct output voltage
				if(amplitude > (Ramp_max / 2))
				{
					Pout_sum += Pout_abs;
					Ramp_count++;
				}
			}
			else
			{
				Pout_sum /= Ramp_count;				//Average power over entire ramp
				Pout_avg = (u16)Pout_sum;
				Pout_sum = 0;
				Ramp_count = 0;
				
				if(SYS_MODE == SYSTEM_MODE_MAN)
				{
					INV_MODE = INV_MODE_RUNNING;	//In Manual mode,Once ramp-up is complete, go to run mode.
					UART_printf("\rRamp complete");
				}
				if(SYS_MODE == SYSTEM_MODE_AUTO)	//In Auto mode, check for the presence of a load after ramp-up
				{
					if(Pout_avg > Psense_ramp)
					{
						INV_MODE = INV_MODE_RUNNING;	//If there is enough load, go to run mode
						UART_printf("\rRamp complete - Load sense OK");
					}
					else
					{
						INV_MODE = INV_MODE_STOPPED;		//Not enough load, stop inverter
						Sense_count = 0;					//Re-start load-sensing timer
						UART_printf("\rRamp complete - Load sense Failed");
					}
					UART_printf("\rPout avg at end of ramp: ");
					UART_S16_Tx(Pout_avg);						//Useful debug info for debugging load-sensing
				}
			}
			Green_LED |= 0b00001000;						//Turn on Green Inverter LED
			break;
		case INV_MODE_RUNNING:
			if(amplitude_target > amp_max) amplitude_target = amp_max;	//Apply limits (Increase to allow more over-modulation)
			if(amplitude_target < 1) amplitude_target = 1;
			if(Src_rec == 0) amplitude = amplitude_target;
			else
			{
				Error_sum = 0;
				if(amplitude < (amplitude_target - 80)) amplitude += 80;
				else Src_rec = 0;
			}
			Pout_sum += Pout_abs;
			Ramp_count++;
			if(Ramp_count > 500)
			{
				Pout_sum /= Ramp_count;				//Average power over entire ramp
				Pout_avg = (u16)Pout_sum;
				Pout_sum = 0;
				Ramp_count = 0;
			}
			if(Pout_avg > Psense_run) Sense_count = 0;		//Reset load sense counter if Output power is higher than load sense power 
			Green_LED |= 0b00001000;						//Turn on Green Inverter LED
			break;
		case INV_MODE_REQ_CHARGE:							//Source in spec, start charging
			if(Bat_UV == 1) Bat_UV = 0;						//Clear the Battery Low error if a Source comes online
			if(Inv_in_sync == 1)							//Inverter is synced with the source
			{
				Src_Relay = 1;								//Close the source relay
				Charge_timer_sec = 0;
				Parallel_timer_ms = 0;
				Parallel_timer_sec = 0;
				Chg_inc_cnt = 0;
				Source_chg_dropout = 0;
				Chg_volt_reached = 0;
				Inv_restart_timer++;
				if(Inv_restart_timer >= 6)					//Must wait 6ms before stopping inverter
				{
					Inv_restart_timer = 0;
					amplitude = 0;							//Stop the Inverter
					Green_LED &= 0b11110111;
					PWM_off();
					PWM_charge = 0;							//Set PWM duty cycle to 0
					PWM_on_charge();						//Enable bottom PWM's
					INV_MODE = INV_MODE_CHARGING;
				}
			}
			break;
		case INV_MODE_CHARGING:
			if(Bat_UV == 1) Bat_UV = 0;						//Clear the Battery Low error if charging
			Parallel_timer_ms++;							//Time how long the Inverter is in parallel with the source
			if(Parallel_timer_ms > 1000)
			{
				Parallel_timer_ms = 0;
				Parallel_timer_sec++;
			}
			
			if(Parallel_timer_sec > 64800) Parallel_timer_sec = 64800;	//Can measure a maximum of 18 hours
			
			if((VBat < Vchg_max) && (Ichg < Ichg_max) && (Isrc_RMS < Imax))	//Charging current and voltage can increase
			{
				Chg_inc_cnt++;
				if(Chg_inc_cnt > 62)							//To make increments slower (About 1%/Sec)
				{
					if(PWM_charge < PWM_charge_Max) PWM_charge++;//Increment Duty cycle
					Chg_inc_cnt = 0;
				}
				Chg_dec_cnt = 0;
			}
			
			if(VBat < (Vchg_max - 20)) Chg_volt_reached = 0;				//2V drop in VBat will re-start 2 hour timer
			
			if((VBat > Vchg_max) || (Ichg > Ichg_max) || (Isrc_RMS > Imax))	//Charging voltage / current too high
			{
				Chg_dec_cnt++;
				if(Chg_dec_cnt > 31)							//Slow down decrements a little (About 2%/Sec)
				{
					if(PWM_charge > 0) PWM_charge--;			//Decrease Duty cycle
					Chg_dec_cnt = 0;	
				}
				Chg_inc_cnt = 0;	
			}
			
			if(VBat > 650) PWM_charge = 0;						//Greater than 65V is bad, stop charging
			
			if((VBat >= Vchg_max) && (Chg_volt_reached == 0))
			{
				Chg_volt_reached = 1;															//The required charging voltage has been reached
				if(Parallel_timer_sec < 57600) Charge_timer_sec = Parallel_timer_sec + 7200;	//Set End of charge time
				else Charge_timer_sec = 64800;
			}
			
			if((Chg_volt_reached == 1) && (Parallel_timer_sec >= Charge_timer_sec))
			{
				INV_MODE = INV_MODE_STOP_CHG;		//2 Hours have elapsed at correct charging voltage
			}
			
			break;
		case INV_MODE_STOP_CHG:								//Charge cycle complete, stop charging (Leave Source Relay in)
			amplitude = 0;									//Stop the Inverter
			Green_LED |= 0b00001000;						//Turn Green LED on
			PWM_off();
			PWM_charge = 0;									//Set PWM duty cycle to 0
			Charge_timer_sec = 0;
			Parallel_timer_ms = 0;
			Parallel_timer_sec = 0;
			if((Transformer_const == Transformer_const_48) && (VBat < 480))	//Re-start charging if VBat drops below 2.00VPC
			{
				PWM_charge = 0;								//Set PWM duty cycle to 0
				PWM_on_charge();							//Enable bottom PWM's
				INV_MODE = INV_MODE_CHARGING;
			}
			if((Transformer_const == Transformer_const_36) && (VBat < 360))	//Re-start charging if VBat drops below 2.00VPC
			{
				PWM_charge = 0;								//Set PWM duty cycle to 0
				PWM_on_charge();							//Enable bottom PWM's
				INV_MODE = INV_MODE_CHARGING;
			}
			break;
		case INV_MODE_SRC_REC:								//Re-start the inverter after the source drops out
			Src_Relay = 0;									//Open the source relay
			amplitude = 0;									//Stop the Inverter
			Green_LED &= 0b11110111;						//Turn off the Inverter LED
			PWM_off();										//Stop the PWM
			PWM_charge = 0;									//Set PWM duty cycle to 0
			Inv_restart_timer++;
			if(Inv_restart_timer >= 15)						//Must wait 15ms before re-starting inverter
			{
				Inv_restart_timer = 0;
				Sense_count = 0;
				PWM_on();
				Src_rec = 1;
				Stop_feedback = 2;								//Disable feedback control for 2 cycles
				INV_MODE = INV_MODE_RUNNING;					//Go back to run mode
			}
			break;
		case INV_MODE_FAULT:								//If there is a fault, turn off the Inverter
			Src_Relay = 0;									//Open the source relay
			amplitude = 0;
			Green_LED &= 0b11110111;						//Turn off the Green Inverter LED
			PWM_off();										//Turn off the PWM
			break;
	}
}

//-----------------------------------------------------------------
// Uart 2 RX ISR:
// Uart 2 is the Debug port
//-----------------------------------------------------------------
void __attribute__ ((interrupt, no_auto_psv)) _U2RXInterrupt(void)
{
	unsigned char Debug_offset;
	IFS1bits.U2RXIF = 0;		//Clear Interrupt flag
	if(U2STAbits.OERR == 1)	U2STAbits.OERR = 0;	//Overflow error, ignore it for now
	Debug_offset = Dbg_Start + Dbg_Len;
	Debug_offset &= 0x1F;					//Same as %= 32
	Debug_Buf[Debug_offset] = U2RXREG;
	if(Debug_Buf[Debug_offset] == 13)		//<CR> was received
	{
		Debug_cmd ++;
		UART_printf("Got cmd.\r");
	}
	Dbg_Len++;
}
