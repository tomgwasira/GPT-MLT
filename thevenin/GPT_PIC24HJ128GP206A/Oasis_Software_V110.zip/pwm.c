#include "p24fj128ga006.h"
#include "defines.h"
#include "tables.h"
#include "Sine8192.h"
#include "UART.h"
#include "pwm.h"

//-----------------------------------------------------------------
//PWM Initialisation
//Sets up the PWM Registers, and the associated timer (Timer 2)
//As well as the Timer 2 Interrupt
//-----------------------------------------------------------------
void PWM_Init(void)
{
	
	OC1CON = 0x0000; // Turn off Output Compare 1 Module
	OC2CON = 0x0000; // Turn off Output Compare 2 Module
	OC3CON = 0x0000; // Turn off Output Compare 3 Module
	OC4CON = 0x0000; // Turn off Output Compare 4 Module
	OC5CON = 0x0000; // Turn off Output Compare 5 Module

	
	OC1R = PWM_qtr_period + dead_time; // Initialize Compare Register1 with 0
	OC1RS = (PWM_Period - PWM_qtr_period) - dead_time; // Initialize Secondary Compare Register1 with 0
	OC2R = (PWM_Period - PWM_qtr_period) + dead_time; // Initialize Compare Register2 with 0
	OC2RS = PWM_qtr_period - dead_time; // Initialize Secondary Compare Register2 with 0
	OC3R = PWM_qtr_period + dead_time; // Initialize Compare Register3 with 0
	OC3RS = (PWM_Period - PWM_qtr_period) - dead_time; // Initialize Secondary Compare Register3 with 0
	OC4R = (PWM_Period - PWM_qtr_period) + dead_time; // Initialize Compare Register4 with 0
	OC4RS = PWM_qtr_period - dead_time; // Initialize Secondary Compare Register4 with 0

	PR2 = PWM_Period;

	IFS0bits.OC1IF = 0; //Clear OC1 Interrupt flag
	IFS0bits.OC2IF = 0; //Clear OC2 Interrupt flag
	IFS1bits.OC3IF = 0; //Clear OC3 Interrupt flag
	IFS1bits.OC4IF = 0; //Clear OC4 Interrupt flag
	
	IPC1bits.T2IP = 6; // Setup Timer 2 interrupt priority
	IFS0bits.T2IF = 0; // Clear Timer 2 interrupt flag
	IEC0bits.T2IE = 1; // Enable Timer 2 interrupt

	T2CONbits.TON = 1; // Start Timer2
	
	OC1CON = 0x0005; // Load new compare mode to OC1CON - Dual compare mode, continuous output
	OC2CON = 0x0005; // Load new compare mode to OC2CON - Dual compare mode, continuous output	
	OC3CON = 0x0005; // Load new compare mode to OC3CON - Dual compare mode, continuous output
	OC4CON = 0x0005; // Load new compare mode to OC4CON - Dual compare mode, continuous output
}

//-----------------------------------------------------------------
//Switching frequency calculations
//Switching frequency is a setpoint, so we must calculate all the
//values that depend on the switching frequency
//-----------------------------------------------------------------
void Sw_freq_calc(void)
{
	PWM_limit = 16000000;				//Just using PWM_limit as a u32 temp variable here
	PWM_limit /= (u32)(Sw_freq);
	PWM_Period = (u16)(PWM_limit);
	PWM_qtr_period = PWM_Period >> 2;
	
	PWM_charge_Max = PWM_Period >> 1;	//Set Maximum duty cycle while charging to 50%

	amp_max = PWM_Period;
		
	PWM_offset = (u32)(PWM_Period);
	PWM_limit = (u32)(PWM_Period);
	PWM_offset <<= 10;
	PWM_limit <<= 9;
	PWM_offset += PWM_limit;
	
	PWM_limit = (u32)(PWM_Period);

	PWM_limit *= 38;	//Calculate limits for maximum 95% duty cycle
	PWM_limit *= 2048;
	PWM_limit /= 39;
	PWM_limit -= PWM_offset;
	
	
	UART_printf("\rPWM Period Register = ");
	UART_Int_TX(PWM_Period, 5);
	UART_printf("\rPWM qtr period = ");
	UART_Int_TX(PWM_qtr_period, 5);
	UART_printf("\rPWM offset = ");
	UART_num_Tx(PWM_offset);
	UART_printf("\rPWM limit = ");
	UART_num_Tx(PWM_limit);
	UART_char_Tx(13);
}

//-----------------------------------------------------------------
//Switch off all PWM
//-----------------------------------------------------------------
void PWM_off(void)
{
	OC1CON = 0;	//Disable Output compare 1 module (Turn off PWM)
	OC2CON = 0;	//Disable Output compare 2 module (Turn off PWM)
	OC3CON = 0;	//Disable Output compare 3 module (Turn off PWM)
	OC4CON = 0;	//Disable Output compare 4 module (Turn off PWM)
	PORTDbits.RD0 = 0;	//Force PWM output pins LOW
	PORTDbits.RD1 = 0;
	PORTDbits.RD2 = 0;
	PORTDbits.RD3 = 0;	
}

//-----------------------------------------------------------------
//Switch on all PWM
//-----------------------------------------------------------------
void PWM_on(void)
{
	OC1CON = 0x0005; // Load new compare mode to OC1CON - Dual compare mode
	OC2CON = 0x0005; // Load new compare mode to OC2CON - Dual compare mode	
	OC3CON = 0x0005; // Load new compare mode to OC3CON - Dual compare mode
	OC4CON = 0x0005; // Load new compare mode to OC4CON - Dual compare mode		
}

//-----------------------------------------------------------------
//Switch on Bottom PWM's for Battery charging mode
//-----------------------------------------------------------------
void PWM_on_charge(void)
{
	OC2R = 0;	//Set initial Duty Cycle to 0%
	OC4R = 0;
	OC2RS = 0;
	OC4RS = 0;
	OC1CON = 0; //Disable Output Compare 1 (Top drive 1) 
	OC2CON = 0x0006; // Load new compare mode to OC2CON - Simple PWM mode
	OC3CON = 0; //Disable Output Compare 3 (Top drive 2) 
	OC4CON = 0x0006; // Load new compare mode to OC4CON - Simple PWM mode
}
