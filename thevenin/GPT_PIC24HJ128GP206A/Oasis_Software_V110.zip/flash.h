extern unsigned int calibrations[max_cal_table];
extern int Data_table[max_Data_table];

void Write_cal_flash(void);
void Read_cal_flash(void);
