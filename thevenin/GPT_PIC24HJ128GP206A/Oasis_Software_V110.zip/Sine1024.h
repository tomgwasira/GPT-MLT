
extern const int Sine[1024];
