
#define max_cal_table 31
#define max_Data_table 26

extern unsigned int calibrations[max_cal_table];
extern int Data_table[max_Data_table];

extern unsigned char INV_MODE;
extern unsigned char BatVHighCnt;
extern unsigned char BatVVHigh;
extern unsigned char BatVLowCnt;
extern unsigned char BatVVLow;
extern unsigned char Stop_feedback;

extern int Vac_temp;
extern int Iac_temp;
extern int Vsrc_temp;
extern int Isrc_temp;
extern int Vsrc_old;
extern int Iac_rms_error;
extern int Iac_err_dat;
extern int VInv_Src_temp;
extern int Vinv_old;
extern unsigned long Vac_RMS_sum;
extern unsigned long Iac_RMS_sum;
extern unsigned long Vsrc_RMS_sum;
extern unsigned long Isrc_RMS_sum;
extern unsigned long VBat_sum;
extern long int Pwr_RMS_sum;
extern long int Pwr_src_sum;
extern long int Power_W_sum;
extern long int Power_W_temp;
extern long int Error_sum;
extern unsigned int amplitude_target;
extern unsigned int RMS_Count;
extern unsigned int AVG_Count;
extern unsigned int PWM_Period;
extern unsigned int Inv_sync;
extern unsigned int amp_max;
extern unsigned long Inverter_Load;
extern unsigned long Vac_AVG_temp;
extern unsigned long Iac_AVG_temp;
extern unsigned long Vsrc_AVG_temp;
extern unsigned long Isrc_AVG_temp;
extern unsigned long Power_VA;
extern unsigned long Hs_temp_temp;
extern unsigned long Vbat_temp;
extern unsigned char Transformer_const;
extern unsigned char Zero_cross;
extern unsigned char Master_Phase;
extern unsigned char Master_Phase_Old;
extern unsigned char Inv_Pos;
extern unsigned char Inv_Zero_Cross;


extern signed int Vac_Err;

#define INV_MODE_STOPPED	0
#define INV_MODE_RAMP_UP	1
#define INV_MODE_RUNNING	2
#define INV_MODE_REQ_CHARGE 3
#define INV_MODE_CHARGING	4
#define INV_MODE_STOP_CHG	5
#define INV_MODE_SRC_REC	6
#define INV_MODE_FAULT		7


void ADC_Init(void);
void ADC_measure_all(void);
