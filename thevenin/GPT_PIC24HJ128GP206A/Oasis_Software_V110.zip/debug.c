#include "p24fj128ga006.h"
#include "tables.h"
#include "debug.h"
#include "UART.h"
#include "DEE Emulation 16-bit.h"
#include "flash.h"
#include "lcd.h"
#include "defines.h"

//-------------------------------------------------------
//Print some debug info to the LCD screen (LCD support removed since charging jumpers added)
//-------------------------------------------------------
/*
void Debug_LCD(void)
{
	lcd_home();
	lcd_puts("Vbat =");
	FracDisp(VBat,2,1);
	lcd_puts("V  ");
				
	lcd_puts("Vac =");
	FracDisp(Vac_RMS,3,1);
	lcd_puts("V  ");
	
	lcd_puts("Iac =");
	FracDisp(Iac_RMS,2,2);
	lcd_data('A');

	lcd_line2();			
	lcd_puts("P =");
	IntDisp((unsigned int)Pout,5);
	lcd_puts("VA ");
	IntDisp((unsigned int)PoutW,5);
	lcd_puts("W ");
	
	lcd_puts("Temp =");
	FracDisp(Heatsink_temp,3,1);
	lcd_puts("C ");
	
	lcd_line3();
	if(Bat_UV == 1) lcd_puts("Batt Low!     ");
	if(Inv_OL == 1) lcd_puts("Overload!     ");
	if(Inv_SC == 1) lcd_puts("Short Circuit!");
//	lcd_puts("Iac RAW: ");
//	LongIntDisp(Iac_RAW_sum,10);
	
	lcd_line4();
	if(Bat_UV == 1) lcd_puts("Batt Low!     ");
	if(Inv_OL == 1) lcd_puts("Overload!     ");
	if(Inv_SC == 1) lcd_puts("Short Circuit!");	
}
*/
//-------------------------------------------------------
// Display some information on startup (Output on UART 2)
//-------------------------------------------------------
void Debug_sys_init(void)
{
	UART_printf("MLT Drives - OASIS Inverter V");
	UART_Frac_TX(Version,1,2);
	UART_printf("\r");
	UART_printf(__DATE__);
	UART_printf("\r");
	UART_printf(__TIME__);
	UART_printf("\r");
	UART_printf("RESET Flags set:\r");
	if(RCONbits.POR == 1) UART_printf("Power On Reset\r");
	if(RCONbits.BOR == 1) UART_printf("Brown Out Reset\r");
	if(RCONbits.IDLE == 1) UART_printf("Woke up from Idle\r");
	if(RCONbits.SLEEP == 1) UART_printf("Woke up from Sleep\r");
	if(RCONbits.WDTO == 1) UART_printf("Watch dog Reset\r");
	if(RCONbits.SWR == 1) UART_printf("Reset instruction was executed\r");
	if(RCONbits.EXTR == 1) UART_printf("MCLR pin Reset\r");  
	if(RCONbits.CM == 1) UART_printf("Config Mismatch Reset\r");
	if(RCONbits.IOPUWR == 1) UART_printf("Illegal OPCODE Reset\r");
	if(RCONbits.TRAPR == 1) UART_printf("Trap error Reset\r");   

	UART_printf("\rEnter -h , -H or -? for help\r\r");
	RCON = 0;	
}

//-------------------------------------------------------
//Prints the Inverter mode based on the jumper positions at startup
//-------------------------------------------------------
void Debug_Inv_Mode(unsigned char Jumper_Pos)
{
	if(Jumper_Pos == 0)	UART_printf("Inverter is a Master or Standalone unit.\r");
	if(Jumper_Pos == 1) UART_printf("Inverter is a Slave in a Single Phase installation.\r");
	if(Jumper_Pos == 2) UART_printf("Inverter is Phase 2 in a 3 Phase installation.\r");
	if(Jumper_Pos == 3) UART_printf("Oops - Illegal mode selected somehow.\r");
	if(Jumper_Pos == 4) UART_printf("Inverter is Phase 3 in a 3 Phase installation.\r");
	if(Jumper_Pos == 5) UART_printf("Inverter is Phase 2 in a Split Phase installation.\r");
	if(Jumper_Pos > 5) UART_printf("Oops - Illegal mode selected somehow.\r");
}

//-------------------------------------------------------
//Checks the Debug buffer for a command and acts upon it
//-------------------------------------------------------
void Parse_debug_buffer(void)
{
	unsigned char timeout;
	unsigned char cmd_len = 0;
	unsigned char i;
	unsigned int rx_num;
	unsigned int rx_num2;
	
	timeout = 0;
	//Debug_cmd = 0;
	while(Debug_Buf[Dbg_Start] != '-')
	{
		Dbg_Start++;
		if(Dbg_Len > 0) Dbg_Len--;
		Dbg_Start &= 0x1F;
		timeout++;
		if(timeout > 31) break;	//Something is wrong	
	}
	
	if(Debug_Buf[Dbg_Start] == '-')	//Start of a command
	{
		switch(Debug_Buf[(Dbg_Start + 1) & 0x1F])
		{
			case 'h':
			case 'H':
			case '?':
				cmd_len = 3;	//-h<CR> = 3 chars
				UART_printf("The following commands are accepted:\r");
				UART_printf("-h / -H / -? : Help\r");
				UART_printf("-AS : Shows all setpoint values\r");
				UART_printf("-AD : Shows all data\r");
				UART_printf("-AV : Shows all Voltages\r");
				UART_printf("-AA : Shows all currents\r");
				UART_printf("-AP : Shows all powers\r");
				UART_printf("-MS : Shows the system mode\r");
				UART_printf("-MI : Shows the Inverter mode\r");
				UART_printf("-USx y : Update setpoint x with value y\r");
				break;
			case 'a':
			case 'A':
				cmd_len = 4;	//-Ax<CR> = 4 chars
				switch(Debug_Buf[(Dbg_Start + 2) & 0x1F])
				{
					case 'S':
					case 's':
						for(i = 0; i < max_cal_table; i++)
						{
							UART_Int_TX(i,2);
							UART_char_Tx(' ');
							UART_printf(Cal_names[i].Tag);
							UART_printf("\t\t");
							if(Cal_names[i].Scale > 0)
							{
								UART_Frac_TX(calibrations[i], (5 - Cal_names[i].Scale), Cal_names[i].Scale);	
							}
							else
							{
								UART_Int_TX(calibrations[i], 5);
							}
							UART_printf(Cal_names[i].Units);
							UART_char_Tx(13);
						}
						break;	
					case 'd':
					case 'D':
						for(i = 0; i < max_Data_table; i++)
						{
							UART_printf(Data_names[i].Tag);
							UART_printf("\t\t");
							if(Data_names[i].Scale > 0)
							{
								UART_SFrac_TX(Data_table[i], Data_names[i].Scale);	
							}
							else
							{
								UART_S16_Tx(Data_table[i]);
							}
							UART_printf(Data_names[i].Units);
							UART_char_Tx(13);
						}	
						break;
					case 'v':
					case 'V':
						for(i = 0; i < max_Data_table; i++)
						{
							if((Data_names[i].Units[0] == 'V') && (Data_names[i].Units[1] != 'A'))
							{
								UART_printf(Data_names[i].Tag);
								UART_printf("\t\t");
								if(Data_names[i].Scale > 0)
								{
									UART_SFrac_TX(Data_table[i], Data_names[i].Scale);	
								}
								else
								{
									UART_S16_Tx(Data_table[i]);
								}
								UART_printf(Data_names[i].Units);
								UART_char_Tx(13);
							}
						}	
						break;
					case 'a':
					case 'A':
						for(i = 0; i < max_Data_table; i++)
						{
							if(Data_names[i].Units[0] == 'A')
							{
								UART_printf(Data_names[i].Tag);
								UART_printf("\t\t");
								if(Data_names[i].Scale > 0)
								{
									UART_SFrac_TX(Data_table[i], Data_names[i].Scale);	
								}
								else
								{
									UART_S16_Tx(Data_table[i]);
								}
								UART_printf(Data_names[i].Units);
								UART_char_Tx(13);
							}
						}	
						break;
					case 'p':
					case 'P':
						for(i = 0; i < max_Data_table; i++)
						{
							if(((Data_names[i].Units[0] == 'V') && (Data_names[i].Units[1] == 'A')) || (Data_names[i].Units[0] == 'W'))
							{
								UART_printf(Data_names[i].Tag);
								UART_printf("\t\t");
								if(Data_names[i].Scale > 0)
								{
									UART_SFrac_TX(Data_table[i], Data_names[i].Scale);	
								}
								else
								{
									UART_S16_Tx(Data_table[i]);
								}
								UART_printf(Data_names[i].Units);
								UART_char_Tx(13);
							}
						}	
						break;
				}
				break;
			case 'u':
			case 'U':
				cmd_len = 5;	//-USx<CR> = 5 (Length of numbers must still be added
				switch(Debug_Buf[(Dbg_Start + 2) & 0x1F])
				{
					case 's':
					case 'S':
						rx_num = (Debug_Buf[(Dbg_Start + 3) & 0x1F]) - '0';
						i = 4;
						timeout = 0;
						while(Debug_Buf[(Dbg_Start + i) & 0x1F] != ' ')
						{
							rx_num *= 10;
							rx_num += (Debug_Buf[(Dbg_Start + i) & 0x1F]) - '0';
							i++;
							cmd_len++;
							timeout++;
							if(timeout > 3) break;	//Something is wrong
						}
						i++;
						cmd_len++;
						rx_num2 = (Debug_Buf[(Dbg_Start + i) & 0x1F]) - '0';
						i++;
						cmd_len++;
						timeout = 0;
						while(Debug_Buf[(Dbg_Start + i) & 0x1F] != 13)
						{
							rx_num2 *= 10;
							rx_num2 += (Debug_Buf[(Dbg_Start + i) & 0x1F]) - '0';
							i++;
							cmd_len++;
							if(timeout > 3) break;	//Something is wrong
						}
						UART_printf("Command echo: -US");
						UART_Int_TX(rx_num,2);
						UART_char_Tx(' ');
						UART_Int_TX(rx_num2,5);
						UART_char_Tx(13);
						if(rx_num < max_cal_table)
						{
							calibrations[rx_num] = rx_num2;
							Write_cal_flash();	//Write new calibration values to flash
						}
						else
						{
							UART_printf("Invalid setpoint\r");	
						}
						break;
				}
				break;
			case 'm':
			case 'M':
				cmd_len = 4;	//-Mx<CR> = 4 chars
				switch(Debug_Buf[(Dbg_Start + 2) & 0x1F])
				{
					case 'S':
					case 's':
						UART_printf(System_modes[SYS_MODE].Tag);
						UART_char_Tx(13);
					break;
					case 'i':
					case 'I':
						UART_printf(Inverter_modes[INV_MODE].Tag);
						UART_char_Tx(13);
					break;
				}	
			break;
		}
		Dbg_Start += cmd_len;
		Dbg_Len -= cmd_len;
		Dbg_Start &= 0x1F;
		//Debug_cmd = 0;
	}
}
