
extern const int Sine[8192];
