//tables.c  automatically created in Excel

#include "tables.h"

const CalType Cal_names[max_cal_table] = {

{"V Batt cal"," ",0},
{"V inv cal"," ",0},
{"I inv cal"," ",0},
{"V src cal","",0},
{"I src cal","",0},
{"Sink Temp cal"," ",0},
{"Ramp max sp"," ",0},
{"Switching Frequency","Hz",0},
{"Output Frequency","Hz",1},
{"24V Batt high sp","V",1},
{"24V Ball low sp","V",1},
{"24V Batt Recon sp","V",1},
{"36V Batt high sp","V",1},
{"36V Ball low sp","V",1},
{"36V Batt Recon sp","V",1},
{"48V Batt high sp","V",1},
{"48V Ball low sp","V",1},
{"48V Batt Recon sp","V",1},
{"V out sp","V",1},
{"Inv size sp","VA",0},
{"Load sense run","W",0},
{"Load sense ramp","W",0},
{"Load sense interval","ms",0},
{"Load sense time to off","ms",0},
{"Sink Temp High","�C",1},
{"Sink Temp recover","�C",1},
{"V ac Kp","",0},
{"V ac Ki","",0},
{"I chg Hi","A",2},
{"I chg Lo","A",2},
{"Error timeout","s",0},
};


const CalType Data_names[max_Data_table] = {

{"Amplitude (modulation)"," ",0},
{"V Batt","V",1},
{"Vac RMS","V",1},
{"Iac RMS","A",2},
{"Vac OFFSET","V",0},
{"Iac OFFSET","A",0},
{"Pout","VA",0},
{"Vsrc RMS","V",1},
{"Isrc RMS","A",2},
{"Vsrc AVG","V",0},
{"Isrc AVG","A",0},
{"Sink Temp","�C",1},
{"Pout","W",0},
{"Psrc","W",0},
{"Iac Max","A",2},
{"Ichg","A",2},
{"Ichg Max","A",2},
{"Vchg Max","V",1},
{"Pout AVG","W",0},
{"Red LED","",0},
{"Yellow LED","",0},
{"Green LED","",0},
{"Inverter Load","",0},
{"Master Load","",0},
{"Inverter PF","",0},
{"Phase offset","",0},
};

const TagType System_modes[3] = {
{"System Off"},
{"Manual Mode"},
{"Auto Mode"},

};

const TagType Inverter_modes[4] = {
{"Inverter Stopped"},
{"Inverter Ramp up"},
{"Inverter Running"},
{"Inverter Fault"},
};
