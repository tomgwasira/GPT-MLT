extern unsigned int PR3_calc;
extern unsigned int PR3_50Hz;
extern unsigned int PR3_53Hz;

void Timer4_Init(void);
void Timer3_Init(void);

