
unsigned long sqrt2(unsigned long N);
