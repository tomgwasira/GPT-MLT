#define Version 110

#define INV_MODE_STOPPED	0
#define INV_MODE_RAMP_UP	1
#define INV_MODE_RUNNING	2
#define INV_MODE_REQ_CHARGE 3
#define INV_MODE_CHARGING	4
#define INV_MODE_STOP_CHG	5
#define INV_MODE_SRC_REC	6
#define INV_MODE_FAULT		7

#define SYSTEM_MODE_OFF		0
#define SYSTEM_MODE_MAN		1
#define SYSTEM_MODE_AUTO	2

#define Inv_LED				LATGbits.LATG7
#define Inv_LED_tris		TRISGbits.TRISG7
#define OL_LED				LATGbits.LATG9
#define OL_LED_tris			TRISGbits.TRISG9
#define Bat_Low_LED 		LATGbits.LATG8
#define Bat_Low_LED_tris	TRISGbits.TRISG8
#define Auto_Sw				PORTBbits.RB15
#define Auto_Sw_tris		TRISBbits.TRISB15
#define Man_Sw				PORTBbits.RB14
#define Man_Sw_tris			TRISBbits.TRISB14
#define Driver_Error_tris	TRISCbits.TRISC14
#define Driver_Error		PORTCbits.RC14
#define Buzzer_tris			TRISDbits.TRISD4
#define Buzzer				LATDbits.LATD4
#define HB_LED				LATFbits.LATF0
#define HB_LED_tris			TRISFbits.TRISF0
#define Vsel_tris			TRISBbits.TRISB12
#define Vsel_jmp			PORTBbits.RB12
#define Vsel_out			LATBbits.LATB12
#define Relay1				LATDbits.LATD5
#define Relay1_tris			TRISDbits.TRISD5
#define Src_Relay			LATDbits.LATD6
#define Src_Relay_tris		TRISDbits.TRISD6
#define Inverter_Relay		LATDbits.LATD7
#define Inv_Relay_tris		TRISDbits.TRISD7
#define Ichg_sel1			LATEbits.LATE7
#define Ichg_sel1_tris		TRISEbits.TRISE7
#define Ichg_sel2			PORTEbits.RE6
#define Ichg_sel2_tris		TRISEbits.TRISE6
#define Vchg_sel1			LATEbits.LATE5
#define Vchg_sel1_tris		TRISEbits.TRISE5
#define Vchg_sel2			PORTEbits.RE4
#define Vchg_sel2_tris		TRISEbits.TRISE4
#define In_E0				PORTEbits.RE0
#define Tris_E0				TRISEbits.TRISE0
#define Out_E1				LATEbits.LATE1
#define Tris_E1				TRISEbits.TRISE1
#define In_D10				PORTDbits.RD10
#define Tris_D10			TRISDbits.TRISD10
#define Out_D8				LATDbits.LATD8
#define Tris_D8				TRISDbits.TRISD8
#define Master_TX			LATFbits.LATF3
#define Master_Tris			TRISFbits.TRISF3
#define Slave_RX			PORTFbits.RF2
#define Slave_Tris			TRISFbits.TRISF2

#define OUTPUT 0
#define INPUT 1

#define u8 unsigned char
#define u16 unsigned int
#define u32 unsigned long
#define s16 int
#define s32 long
